# Integer Anchored Densest Subhypergraph Search via Reusable Orientations

## Algorithms

| Algorithm | Method | Source file |
|---|---|---|
| CB-Global | `cb_global` | `algorithms/cb_global.cpp` |
| CB-Local | `cb_local` | `algorithms/cb_local.cpp` |
| HGV-Global | `hgv_global` | `algorithms/hgv_global.cpp` |
| HGV-Local | `hgv_local` | `algorithms/hgv_local.cpp` |
| HGV-Global-I | `hgv_global_i` | `algorithms/hgv_global.cpp` |
| HGV-Local-I | `hgv_local_i` | `algorithms/hgv_local.cpp` |
| Dynamic-Path | `dynamic_path` | `algorithms/dynamic_path.cpp` |

The HGV-I variants use integer stopping conditions and share code with their corresponding HGV variants. The `main.cpp` file handles command-line arguments and algorithm selection. Shared data structures and utility functions are implemented in `common/`, while algorithm-specific shared routines are provided in `algorithms/cb_shared.*` and `algorithms/hgv_shared.*`.

## Datasets

The package includes the Walmart hypergraph used in the experiments (`example/walmart-trips.hgr`), with 88,860 vertices and 65,979 hyperedges.

Each line lists the vertex IDs of one hyperedge, separated by spaces. The file has no header or edge weights. Vertex IDs are nonnegative integers; each hyperedge contains at least two distinct vertices. An isolated vertex may be declared as `v ID`.

## Queries

`example/walmart-trips_queries.txt` contains ten Walmart queries (q0--q9), each with 64 reference vertices and four anchors. Each query consists of an `R` line followed by an `A` line. The query index is zero-based: 0 selects q0 and 9 selects q9. The anchor set `A` must be a nonempty subset of `R`, and all listed vertices must belong to the input hypergraph.

## Updates

`example/updates.txt` contains deletion and restoration operations for ten hyperedges. Each hyperedge is restored before the next one is deleted. The supported operations are:

```text
- EDGE_ID
+ EDGE_ID
insert ID1 ID2 ...
```

Edge IDs start at zero in input order. The `insert` operation adds a new hyperedge over existing vertices.

## Build

A C++17 compiler (GCC) and Bash are required. Run from the package directory:

```bash
bash build.sh
```

This produces `bin/iadsh`. Set `CXX` to use a different compiler.

## Run

Select a method, provide the graph and query files, and specify the query index. For example:

```bash
./bin/iadsh cb_local example/walmart-trips.hgr example/walmart-trips_queries.txt 0
./bin/iadsh hgv_global_i example/walmart-trips.hgr example/walmart-trips_queries.txt 9
```

For Dynamic-Path, supply the update file after the query index:

```bash
./bin/iadsh dynamic_path example/walmart-trips.hgr example/walmart-trips_queries.txt 0 example/updates.txt
```

Results are written as JSON objects to standard output. Run `./bin/iadsh --help` for command syntax.
