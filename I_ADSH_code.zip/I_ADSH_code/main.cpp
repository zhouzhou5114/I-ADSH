#include "algorithms/cb.hpp"
#include "algorithms/dynamic_path.hpp"
#include "algorithms/hgv.hpp"
#include "common/io.hpp"
#include "common/score.hpp"

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>


using namespace iadsh;
using namespace iadsh::io;

namespace {
std::size_t parse_query_index(const std::string& text) {
    if (text.empty() || text.front() == '-') {
        throw std::runtime_error("query index must be a nonnegative integer");
    }
    std::size_t consumed = 0;
    const auto value = std::stoull(text, &consumed);
    if (consumed != text.size()) throw std::runtime_error("invalid query index: " + text);
    return static_cast<std::size_t>(value);
}

void solve_static(const std::string& method, const Input& data) {
    const auto& graph = data.graph;
    std::vector<int> answer;
    int level = 0;
    if (method == "CB-Global") {
        const auto result = batched_ceil_balance_global_all_closures(graph);
        answer = result.best_set; level = result.best_level;
    } else if (method == "CB-Local") {
        const QueryGraphIndex graph_index(graph, true);
        const CeilBalanceStaticIndex index(graph, graph_index);
        const CeilBalanceQueryState query(graph, index, data.reference, data.anchors);
        const auto result = lazy_batched_ceil_balance_local_all_closures(
            graph, query, std::numeric_limits<std::size_t>::max());
        answer = result.best_set; level = result.best_level;
    } else {
        const QueryGraphIndex graph_index(graph);
        const Www24Index index(graph, graph_index, data.reference, data.anchors);
        Www24Result result;
        if (method == "HGV-Global") result = www24_global(graph, index);
        else if (method == "HGV-Local") result = www24_local(graph, index);
        else if (method == "HGV-Global-I") result = www24_global_integer_stop(graph, index);
        else if (method == "HGV-Local-I") result = www24_local_integer_stop(graph, index);
        else throw std::runtime_error("unknown algorithm");
        answer = result.best_set;
        level = integer_level(graph, answer, RewardPolicy::WWW);
    }
    print(method, data, answer, level, 0);
}

void solve_dynamic(Input& data, const std::string& stream) {
    auto state = initialize_dynamic_all_closures(data.graph, data.anchors);
    print("Dynamic-Path", data, state.witness, state.best_level, 0);
    if (stream.empty()) return;
    std::size_t step = 0;
    for (const auto& line : lines(stream)) {
        std::istringstream row(line);
        std::string op;
        row >> op;
        int edge_id = -1;
        bool insertion = false;
        if (op == "+" || op == "-") {
            std::string extra;
            if (!(row >> edge_id) || (row >> extra)) throw std::runtime_error("expected + ID or - ID");
            insertion = op == "+";
            if (insertion) {
                if (edge_id < 0 || edge_id >= static_cast<int>(data.graph.edges.size()))
                    throw std::runtime_error("restored edge ID is out of range");
                const auto& pins = data.graph.edges[edge_id].pins;
                for (std::size_t e = 0; e < data.graph.edges.size(); ++e)
                    if (e != static_cast<std::size_t>(edge_id) && data.graph.edges[e].active &&
                        data.graph.edges[e].pins == pins)
                        throw std::runtime_error("restore would create a duplicate active hyperedge");
                data.graph.restore_edge(edge_id);
            } else data.graph.erase_edge(edge_id);
        } else if (op == "insert") {
            std::vector<int> pins;
            for (Id id : ids(row)) pins.push_back(vertex(data, id));
            std::sort(pins.begin(), pins.end());
            for (const auto& edge : data.graph.edges)
                if (edge.active && edge.pins == pins) throw std::runtime_error("duplicate active hyperedge");
            edge_id = data.graph.insert_edge(std::move(pins));
            insertion = true;
        } else throw std::runtime_error("unknown update operation");
        update_dynamic_all_closures(data.graph, state, edge_id, insertion);
        print("Dynamic-Path", data, state.witness, state.best_level, ++step, edge_id);
    }
}
}  // namespace

int main(int argc, char** argv) {
    try {
        if (argc == 2 && std::string(argv[1]) == "--help") {
            std::cout << "Usage: " << argv[0] << " METHOD GRAPH QUERIES QUERY_INDEX [UPDATES]\n"
                      << "METHOD: cb_global, cb_local, hgv_global, hgv_local,\n"
                      << "        hgv_global_i, hgv_local_i, dynamic_path\n";
            return 0;
        }
        if (argc < 2) throw std::runtime_error("usage: iadsh METHOD GRAPH QUERIES QUERY_INDEX [UPDATES]");
        const std::map<std::string, std::string> methods{
            {"cb_global","CB-Global"}, {"cb_local","CB-Local"},
            {"hgv_global","HGV-Global"}, {"hgv_local","HGV-Local"},
            {"hgv_global_i","HGV-Global-I"}, {"hgv_local_i","HGV-Local-I"},
            {"dynamic_path","Dynamic-Path"}};
        const auto selected = methods.find(argv[1]);
        if (selected == methods.end()) throw std::runtime_error("unknown algorithm: " + std::string(argv[1]));
        const char* algorithm = selected->second.c_str();
        --argc;
        ++argv;
        const bool dynamic = std::string(algorithm) == "Dynamic-Path";
        if (argc == 2 && std::string(argv[1]) == "--help") {
            std::cout << "Usage: " << argv[0] << " GRAPH QUERIES QUERY_INDEX"
                      << (dynamic ? " [UPDATES]" : "") << "\n"
                      << "GRAPH: one hyperedge per line; optional v ID declarations.\n"
                      << "QUERIES: repeated pairs of R and A lines.\n"
                      << "QUERY_INDEX: zero-based index in the query file.\n";
            if (dynamic) std::cout << "UPDATES: - EDGE_ID, + EDGE_ID, or insert VERTEX_ID...\n";
            return 0;
        }
        if (argc != 4 && !(dynamic && argc == 5))
            throw std::runtime_error("usage: executable GRAPH QUERIES QUERY_INDEX" + std::string(dynamic ? " [UPDATES]" : ""));
        const auto query_index = parse_query_index(argv[3]);
        auto data = load(argv[1], argv[2], query_index);
        if (dynamic) solve_dynamic(data, argc == 5 ? argv[4] : "");
        else solve_static(algorithm, data);
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "error: " << error.what() << '\n';
        return 1;
    }
}
