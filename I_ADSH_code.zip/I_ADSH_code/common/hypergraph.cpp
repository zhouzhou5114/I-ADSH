#include "hypergraph.hpp"

#include <algorithm>
#include <fstream>
#include <sstream>
#include <stdexcept>

namespace iadsh {
namespace {

std::vector<std::string> data_lines(const std::string& path) {
    std::ifstream input(path);
    if (!input) throw std::runtime_error("cannot open hypergraph file: " + path);
    std::vector<std::string> lines;
    std::string line;
    while (std::getline(input, line)) {
        const auto comment = line.find('#');
        if (comment != std::string::npos) line.erase(comment);
        const auto first = line.find_first_not_of(" \t\r\n");
        if (first == std::string::npos) continue;
        const auto last = line.find_last_not_of(" \t\r\n");
        lines.push_back(line.substr(first, last - first + 1));
    }
    return lines;
}

std::vector<int> parse_labeled_set(const std::string& line, const std::string& label) {
    std::istringstream in(line);
    std::string actual;
    int count = -1;
    in >> actual >> count;
    if (actual != label || count < 0) {
        throw std::runtime_error("expected '" + label + " k ...' line");
    }
    std::vector<int> values;
    values.reserve(static_cast<std::size_t>(count));
    for (int i = 0; i < count; ++i) {
        int value = -1;
        if (!(in >> value)) throw std::runtime_error("too few vertices on " + label + " line");
        values.push_back(value);
    }
    std::string extra;
    if (in >> extra) throw std::runtime_error("too many tokens on " + label + " line");
    return values;
}

}  // namespace

void Hypergraph::validate() const {
    if (n <= 0) throw std::runtime_error("hypergraph must contain at least one vertex");
    if (is_anchor.size() != static_cast<std::size_t>(n) ||
        is_reference.size() != static_cast<std::size_t>(n)) {
        throw std::runtime_error("anchor/reference flags have wrong size");
    }
    bool has_anchor = false;
    for (int v = 0; v < n; ++v) {
        if (is_anchor[v]) {
            has_anchor = true;
            if (!is_reference[v]) throw std::runtime_error("every anchor must belong to the reference set");
        }
    }
    if (!has_anchor) throw std::runtime_error("at least one mandatory anchor is required");

    for (std::size_t i = 0; i < edges.size(); ++i) {
        const auto& pins = edges[i].pins;
        if (pins.size() < 2) throw std::runtime_error("singleton hyperedges are not supported");
        for (std::size_t j = 0; j < pins.size(); ++j) {
            if (pins[j] < 0 || pins[j] >= n) throw std::runtime_error("hyperedge pin is out of range");
            if (j > 0 && pins[j - 1] >= pins[j]) {
                throw std::runtime_error("hyperedge pins must be sorted and unique");
            }
        }
    }
}

std::vector<Capacity> Hypergraph::degrees() const {
    std::vector<Capacity> degree(static_cast<std::size_t>(n), 0);
    for (const auto& edge : edges) {
        if (!edge.active) continue;
        for (int v : edge.pins) ++degree[static_cast<std::size_t>(v)];
    }
    return degree;
}

std::vector<Capacity> Hypergraph::penalties() const {
    auto degree = degrees();
    for (int v = 0; v < n; ++v) {
        if (is_reference[v]) degree[static_cast<std::size_t>(v)] = 0;
    }
    return degree;
}

Capacity Hypergraph::edge_reward(std::size_t edge_id, RewardPolicy policy) const {
    const auto& edge = edges.at(edge_id);
    if (!edge.active) return 0;
    if (policy == RewardPolicy::WWW) return 2;
    return static_cast<Capacity>(edge.pins.size());
}

Capacity Hypergraph::total_reward(RewardPolicy policy) const {
    Capacity total = 0;
    for (std::size_t i = 0; i < edges.size(); ++i) total += edge_reward(i, policy);
    return total;
}

std::size_t Hypergraph::active_edge_count() const {
    return static_cast<std::size_t>(std::count_if(
        edges.begin(), edges.end(), [](const Hyperedge& edge) { return edge.active; }));
}

std::size_t Hypergraph::active_pin_count() const {
    std::size_t total = 0;
    for (const auto& edge : edges) if (edge.active) total += edge.pins.size();
    return total;
}

int Hypergraph::insert_edge(std::vector<int> pins) {
    std::sort(pins.begin(), pins.end());
    pins.erase(std::unique(pins.begin(), pins.end()), pins.end());
    if (pins.size() < 2) throw std::runtime_error("inserted hyperedge must have at least two distinct pins");
    for (int v : pins) if (v < 0 || v >= n) throw std::runtime_error("inserted hyperedge pin is out of range");
    edges.push_back({std::move(pins), true});
    return static_cast<int>(edges.size() - 1);
}

void Hypergraph::erase_edge(int edge_id) {
    if (edge_id < 0 || edge_id >= static_cast<int>(edges.size())) {
        throw std::runtime_error("deleted edge id is out of range");
    }
    if (!edges[static_cast<std::size_t>(edge_id)].active) {
        throw std::runtime_error("cannot delete an inactive edge");
    }
    edges[static_cast<std::size_t>(edge_id)].active = false;
}

void Hypergraph::restore_edge(int edge_id) {
    if (edge_id < 0 || edge_id >= static_cast<int>(edges.size())) {
        throw std::runtime_error("restored edge id is out of range");
    }
    if (edges[static_cast<std::size_t>(edge_id)].active) {
        throw std::runtime_error("cannot restore an active edge");
    }
    edges[static_cast<std::size_t>(edge_id)].active = true;
}

Hypergraph load_hypergraph(const std::string& path) {
    const auto lines = data_lines(path);
    if (lines.size() < 3) throw std::runtime_error("hypergraph file is incomplete");

    Hypergraph graph;
    int m = -1;
    {
        std::istringstream in(lines[0]);
        if (!(in >> graph.n >> m) || graph.n <= 0 || m < 0) {
            throw std::runtime_error("first line must be 'n m'");
        }
    }
    graph.is_anchor.assign(static_cast<std::size_t>(graph.n), 0);
    graph.is_reference.assign(static_cast<std::size_t>(graph.n), 0);

    for (int v : parse_labeled_set(lines[1], "anchors")) {
        if (v < 0 || v >= graph.n) throw std::runtime_error("anchor is out of range");
        graph.is_anchor[static_cast<std::size_t>(v)] = 1;
    }
    for (int v : parse_labeled_set(lines[2], "reference")) {
        if (v < 0 || v >= graph.n) throw std::runtime_error("reference vertex is out of range");
        graph.is_reference[static_cast<std::size_t>(v)] = 1;
    }

    if (lines.size() != static_cast<std::size_t>(m + 3)) {
        throw std::runtime_error("declared edge count does not match the number of edge lines");
    }
    graph.edges.reserve(static_cast<std::size_t>(m));
    for (int i = 0; i < m; ++i) {
        std::istringstream in(lines[static_cast<std::size_t>(i + 3)]);
        int rank = -1;
        if (!(in >> rank) || rank < 2) throw std::runtime_error("edge line must start with rank >= 2");
        std::vector<int> pins;
        pins.reserve(static_cast<std::size_t>(rank));
        for (int j = 0; j < rank; ++j) {
            int v = -1;
            if (!(in >> v)) throw std::runtime_error("too few pins on edge line");
            pins.push_back(v);
        }
        std::string extra;
        if (in >> extra) throw std::runtime_error("too many tokens on edge line");
        graph.insert_edge(std::move(pins));
    }
    graph.validate();
    return graph;
}

void save_hypergraph(const Hypergraph& graph, const std::string& path) {
    graph.validate();
    std::ofstream out(path);
    if (!out) throw std::runtime_error("cannot write hypergraph file: " + path);
    out << graph.n << ' ' << graph.active_edge_count() << '\n';
    std::vector<int> anchors, reference;
    for (int v = 0; v < graph.n; ++v) {
        if (graph.is_anchor[v]) anchors.push_back(v);
        if (graph.is_reference[v]) reference.push_back(v);
    }
    out << "anchors " << anchors.size();
    for (int v : anchors) out << ' ' << v;
    out << '\n';
    out << "reference " << reference.size();
    for (int v : reference) out << ' ' << v;
    out << '\n';
    for (const auto& edge : graph.edges) {
        if (!edge.active) continue;
        out << edge.pins.size();
        for (int v : edge.pins) out << ' ' << v;
        out << '\n';
    }
}

RewardPolicy parse_reward_policy(const std::string& value) {
    if (value == "www") return RewardPolicy::WWW;
    if (value == "rank") return RewardPolicy::Rank;
    throw std::runtime_error("unknown reward policy: " + value + " (expected www or rank)");
}

std::string reward_policy_name(RewardPolicy policy) {
    return policy == RewardPolicy::WWW ? "www" : "rank";
}

}  // namespace iadsh
