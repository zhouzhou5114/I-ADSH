#pragma once
#include <cstddef>
#include <cstdint>
#include <vector>
#ifdef PROFILE_ACCESS
#include "hypergraph.hpp"
#include <algorithm>
#include <stdexcept>
#endif

namespace measure {
struct Memory { std::size_t peak = 0, live = 0; };
#ifdef PROFILE_MEMORY
void memory_begin();
Memory memory_end();
Memory memory_snapshot();
void memory_reset_peak();
void memory_pause();
void memory_resume();
#else
inline void memory_begin() {}
inline Memory memory_end() { return {}; }
inline Memory memory_snapshot() { return {}; }
inline void memory_reset_peak() {}
inline void memory_pause() {}
inline void memory_resume() {}
#endif
struct Network { std::size_t vertices, edges, pins; };
struct Access {
    std::size_t vertices = 0, edges = 0, pins = 0, pin_scans = 0;
    std::vector<Network> networks;
};
#ifdef PROFILE_ACCESS
inline bool active = false;
inline std::vector<unsigned char> vertex_seen, edge_seen;
inline const iadsh::Hypergraph* original_graph = nullptr;
inline std::vector<std::size_t> edge_offsets;
inline std::vector<std::uint64_t> pin_bits;
// Profiler-only metadata; constructed before any query, never charged to time,
// memory or original graph-access counts.
inline void prepare_graph(const iadsh::Hypergraph& graph) {
    original_graph = &graph;
    edge_offsets.assign(graph.edges.size()+1,0);
    for (std::size_t e=0; e<graph.edges.size(); ++e)
        edge_offsets[e+1] = edge_offsets[e] + graph.edges[e].pins.size();
    pin_bits.assign((edge_offsets.back()+63)/64,0);
}
inline Access access;
inline void begin(int n, std::size_t m) {
    active = false;
    vertex_seen.assign(n, 0); edge_seen.assign(m, 0);
    if (!original_graph || original_graph->n != n || original_graph->edges.size() != m)
        throw std::runtime_error("Access profiler needs matching graph metadata");
    std::fill(pin_bits.begin(),pin_bits.end(),0);
    access = {}; active = true;
}
inline void vertex(int v) {
    if (active && v >= 0 && v < static_cast<int>(vertex_seen.size()) && !vertex_seen[v]) {
        vertex_seen[v] = 1; ++access.vertices;
    }
}
inline void edge(int e) {
    if (active && e >= 0 && e < static_cast<int>(edge_seen.size()) && !edge_seen[e]) {
        edge_seen[e] = 1; ++access.edges;
    }
}
inline void pin(int e, int v) {
    if (!active || v < 0 || v >= static_cast<int>(vertex_seen.size())) return;
    edge(e); vertex(v); ++access.pin_scans;
    if (e < 0 || e >= static_cast<int>(original_graph->edges.size()) || !original_graph->edges[e].active)
        throw std::runtime_error("Access profiler saw an invalid/inactive edge");
    const auto& pins = original_graph->edges[e].pins;
    const auto found = std::lower_bound(pins.begin(),pins.end(),v);
    if (found==pins.end() || *found!=v)
        throw std::runtime_error("Access profiler saw a non-incidence");
    const auto position = edge_offsets[e] + (found-pins.begin());
    auto& word = pin_bits[position/64];
    const auto mask = std::uint64_t(1) << (position%64);
    if (!(word&mask)) { word |= mask; ++access.pins; }
}
inline void network(std::size_t v, std::size_t e, std::size_t p) {
    if (active) access.networks.push_back({v,e,p});
}
inline Access end() { active = false; return std::move(access); }
#else
template <typename Graph> inline void prepare_graph(const Graph&) {}
inline void begin(int, std::size_t) {}
inline void vertex(int) {}
inline void edge(int) {}
inline void pin(int, int) {}
inline void network(std::size_t, std::size_t, std::size_t) {}
inline Access end() { return {}; }
#endif
}
