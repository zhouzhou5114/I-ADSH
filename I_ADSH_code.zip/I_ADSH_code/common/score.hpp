#pragma once
#include "hypergraph.hpp"
#include <limits>
#include <stdexcept>

namespace iadsh {
Capacity numerator(const Hypergraph&, const std::vector<char>&, RewardPolicy);
int integer_level(const Hypergraph&, const std::vector<int>&, RewardPolicy);
std::vector<int> anchor_set(const Hypergraph&);
namespace detail {
inline Capacity ceil_div(Capacity numerator_value, Capacity denominator) {
    if (denominator <= 0) throw std::runtime_error("ceil division requires a positive denominator");
    if (numerator_value >= 0) return (numerator_value + denominator - 1) / denominator;
    return -((-numerator_value) / denominator);
}
}  // namespace detail
}  // namespace iadsh
