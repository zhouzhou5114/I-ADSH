#include "score.hpp"
#include <algorithm>

namespace iadsh {

Capacity numerator(
    const Hypergraph& graph,
    const std::vector<char>& in_set,
    RewardPolicy policy) {
    if (in_set.size() != static_cast<std::size_t>(graph.n)) {
        throw std::runtime_error("membership vector has wrong size");
    }
    Capacity value = 0;
    for (std::size_t i = 0; i < graph.edges.size(); ++i) {
        if (!graph.edges[i].active) continue;
        bool inside = true;
        for (int v : graph.edges[i].pins) {
            if (!in_set[static_cast<std::size_t>(v)]) {
                inside = false;
                break;
            }
        }
        if (inside) value += graph.edge_reward(i, policy);
    }
    const auto penalty = graph.penalties();
    for (int v = 0; v < graph.n; ++v) {
        if (in_set[static_cast<std::size_t>(v)]) value -= penalty[static_cast<std::size_t>(v)];
    }
    return value;
}

int integer_level(
    const Hypergraph& graph,
    const std::vector<int>& set,
    RewardPolicy policy) {
    if (set.empty()) return std::numeric_limits<int>::min();
    std::vector<char> in_set(static_cast<std::size_t>(graph.n), 0);
    for (int v : set) in_set[static_cast<std::size_t>(v)] = 1;
    return static_cast<int>(detail::ceil_div(
        numerator(graph, in_set, policy), static_cast<Capacity>(set.size())));
}

std::vector<int> anchor_set(const Hypergraph& graph) {
    std::vector<int> result;
    for (int v = 0; v < graph.n; ++v) if (graph.is_anchor[v]) result.push_back(v);
    return result;
}

}  // namespace iadsh
