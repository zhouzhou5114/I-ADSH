#include "io.hpp"
#include "score.hpp"

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>


namespace iadsh::io {

std::vector<std::string> lines(const std::string& filename) {
    std::ifstream in(filename);
    if (!in) throw std::runtime_error("cannot open file: " + filename);
    std::vector<std::string> result;
    std::string line;
    while (std::getline(in, line)) {
        line.erase(line.find('#') == std::string::npos ? line.size() : line.find('#'));
        if (line.find_first_not_of(" \t\r\n") != std::string::npos) result.push_back(line);
    }
    return result;
}

std::vector<Id> ids(std::istringstream& row) {
    std::vector<Id> result;
    Id v;
    while (row >> v) {
        if (v < 0) throw std::runtime_error("vertex IDs must be nonnegative integers");
        result.push_back(v);
    }
    if (!row.eof()) throw std::runtime_error("invalid integer in input");
    auto copy = result;
    std::sort(copy.begin(), copy.end());
    if (std::adjacent_find(copy.begin(), copy.end()) != copy.end())
        throw std::runtime_error("duplicate vertex in one set or hyperedge");
    return result;
}



int vertex(const Input& data, Id external) {
    const auto it = data.internal.find(external);
    if (it == data.internal.end()) throw std::runtime_error("vertex ID is absent from graph");
    return it->second;
}

Input load(const std::string& graph_file, const std::string& query_file, std::size_t query_index) {
    Input data;
    std::set<Id> vertices;
    std::vector<std::vector<Id>> edges;
    std::set<std::vector<Id>> distinct;
    for (const auto& line : lines(graph_file)) {
        std::istringstream row(line);
        row >> std::ws;
        if (row.peek() == 'v') {
            std::string label;
            row >> label;
            const auto values = ids(row);
            if (label != "v" || values.size() != 1) throw std::runtime_error("expected v ID");
            vertices.insert(values.front());
        } else {
            auto pins = ids(row);
            if (pins.size() < 2) throw std::runtime_error("a hyperedge needs at least two pins");
            std::sort(pins.begin(), pins.end());
            if (!distinct.insert(pins).second) throw std::runtime_error("duplicate hyperedge");
            vertices.insert(pins.begin(), pins.end());
            edges.push_back(std::move(pins));
        }
    }
    if (vertices.empty()) throw std::runtime_error("graph has no vertices");
    if (vertices.size() > static_cast<std::size_t>(std::numeric_limits<int>::max()))
        throw std::runtime_error("too many vertices for integer indexing");
    data.external.assign(vertices.begin(), vertices.end());
    for (Id id : data.external) data.internal[id] = static_cast<int>(data.internal.size());
    data.graph.n = static_cast<int>(vertices.size());
    data.graph.is_anchor.assign(vertices.size(), 0);
    data.graph.is_reference.assign(vertices.size(), 0);
    for (const auto& pins : edges) {
        std::vector<int> edge;
        for (Id id : pins) edge.push_back(vertex(data, id));
        data.graph.edges.push_back({std::move(edge), true});
    }
    std::vector<std::pair<std::vector<Id>, std::vector<Id>>> queries;
    std::vector<Id> current_r, current_a;
    bool has_r = false, has_a = false;
    for (const auto& line : lines(query_file)) {
        std::istringstream row(line);
        std::string label;
        row >> label;
        auto values = ids(row);
        if (values.empty()) throw std::runtime_error("R and A must be nonempty");
        if (label == "R" && !has_r && !has_a) {
            current_r = std::move(values);
            has_r = true;
        } else if (label == "A" && has_r && !has_a) {
            current_a = std::move(values);
            has_a = true;
            queries.emplace_back(std::move(current_r), std::move(current_a));
            current_r.clear();
            current_a.clear();
            has_r = false;
            has_a = false;
        } else {
            throw std::runtime_error("each query must contain one R line followed by one A line");
        }
    }
    if (has_r || has_a) throw std::runtime_error("incomplete query: expected both R and A");
    if (queries.empty()) throw std::runtime_error("query file contains no queries");
    if (query_index >= queries.size()) throw std::runtime_error("query index is out of range");

    const auto& selected_query = queries[query_index];
    std::set<Id> reference_ids(selected_query.first.begin(), selected_query.first.end());
    for (Id id : selected_query.second) {
        if (!reference_ids.count(id)) throw std::runtime_error("anchor set A must be a subset of R");
    }
    for (Id id : selected_query.first) data.reference.push_back(vertex(data, id));
    for (Id id : selected_query.second) data.anchors.push_back(vertex(data, id));
    std::sort(data.reference.begin(), data.reference.end());
    std::sort(data.anchors.begin(), data.anchors.end());
    for (int v : data.reference) data.graph.is_reference[v] = 1;
    for (int v : data.anchors) data.graph.is_anchor[v] = 1;
    data.graph.validate();
    return data;
}

void print(const std::string& algorithm, const Input& data,
           const std::vector<int>& answer, int level, std::size_t step, int edge_id) {
    auto set = answer;
    std::sort(set.begin(), set.end());
    if (set.empty()) throw std::runtime_error("solver returned an empty set");
    std::vector<char> membership(static_cast<std::size_t>(data.graph.n), 0);
    for (int v : set) membership.at(v) = 1;
    const Capacity score = numerator(data.graph, membership, RewardPolicy::WWW);
    std::cout << std::setprecision(17)
              << "{\"algorithm\":\"" << algorithm << "\",\"step\":" << step;
    if (edge_id >= 0) std::cout << ",\"edge_id\":" << edge_id;
    std::cout << ",\"level\":" << level << ",\"numerator\":" << score
              << ",\"scaled_density\":" << static_cast<double>(score) / set.size()
              << ",\"vertices\":[";
    for (std::size_t i = 0; i < set.size(); ++i) {
        if (i) std::cout << ',';
        std::cout << data.external.at(set[i]);
    }
    std::cout << "]}\n";
}


}  // namespace iadsh::io
