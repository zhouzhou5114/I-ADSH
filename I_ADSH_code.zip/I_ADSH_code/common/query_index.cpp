#include "query_index.hpp"

#include <stdexcept>

namespace iadsh {

QueryGraphIndex::QueryGraphIndex(
    const Hypergraph& graph,
    bool build_ceil_balance)
    : incident_edges(static_cast<std::size_t>(graph.n)),
      degree(static_cast<std::size_t>(graph.n), 0),
      fractional_degree(static_cast<std::size_t>(graph.n), 0.0),
      ceil_balance_ready(build_ceil_balance) {
    graph.validate();
    active_edges.reserve(graph.active_edge_count());
    if (ceil_balance_ready) {
        base_token_owner.assign(
            graph.edges.size(), std::array<int, 2>{-2, -2});
        base_bank_ordinal.assign(
            graph.edges.size(), std::array<int, 2>{-1, -1});
        base_vertex_load.assign(static_cast<std::size_t>(graph.n), 0);
        base_held_head.assign(static_cast<std::size_t>(graph.n), -1);
        base_held_edge.reserve(2 * graph.edges.size());
        base_held_next.reserve(2 * graph.edges.size());
    }
    for (int edge_id = 0;
         edge_id < static_cast<int>(graph.edges.size());
         ++edge_id) {
        const auto& edge = graph.edges[static_cast<std::size_t>(edge_id)];
        if (!edge.active) continue;
        if (edge.pins.empty()) {
            throw std::runtime_error("active hyperedge has no pins");
        }
        active_edges.push_back(edge_id);
        const double share = 1.0 / static_cast<double>(edge.pins.size());
        for (std::size_t pin = 0; pin < edge.pins.size(); ++pin) {
            const int v = edge.pins[pin];
            incident_edges[static_cast<std::size_t>(v)].push_back(edge_id);
            ++degree[static_cast<std::size_t>(v)];
            fractional_degree[static_cast<std::size_t>(v)] += share;
            if (ceil_balance_ready && pin < 2) {
                const int token = static_cast<int>(pin);
                base_token_owner[static_cast<std::size_t>(edge_id)]
                                [static_cast<std::size_t>(token)] = v;
                ++base_vertex_load[static_cast<std::size_t>(v)];
                const int link = static_cast<int>(base_held_edge.size());
                base_held_edge.push_back(edge_id);
                base_held_next.push_back(
                    base_held_head[static_cast<std::size_t>(v)]);
                base_held_head[static_cast<std::size_t>(v)] = link;
            }
        }
        if (ceil_balance_ready) {
            for (int token = static_cast<int>(
                     std::min<std::size_t>(2, edge.pins.size()));
                 token < 2;
                 ++token) {
                base_token_owner[static_cast<std::size_t>(edge_id)]
                                [static_cast<std::size_t>(token)] = -1;
                base_bank_ordinal[static_cast<std::size_t>(edge_id)]
                                 [static_cast<std::size_t>(token)] =
                    static_cast<int>(base_bank_tokens.size());
                base_bank_tokens.push_back({edge_id, token});
            }
        }
    }
}

}  // namespace iadsh
