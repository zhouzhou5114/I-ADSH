#pragma once
#include "hypergraph.hpp"
#include <iterator>
namespace iadsh {
// Lazy filtering keeps immutable original incidence lists useful after deletes.
// Iteration reads active marks and allocates no per-query copy of adjacency.
struct ActiveIncidence {
    const Hypergraph* graph;
    const std::vector<int>* edges;
    std::size_t count;
    struct Iterator {
        using iterator_category=std::forward_iterator_tag;
        using value_type=int;using difference_type=std::ptrdiff_t;
        using pointer=const int*;using reference=const int&;
        const Hypergraph* graph=nullptr;
        std::vector<int>::const_iterator at,end;
        void skip(){while(at!=end&&!graph->edges[*at].active)++at;}
        reference operator*()const{return *at;}
        pointer operator->()const{return &*at;}
        Iterator& operator++(){++at;skip();return *this;}
        Iterator operator++(int){auto x=*this;++*this;return x;}
        bool operator==(const Iterator& r)const{return at==r.at;}
        bool operator!=(const Iterator& r)const{return !(*this==r);}
    };
    Iterator begin()const{Iterator r{graph,edges->begin(),edges->end()};r.skip();return r;}
    Iterator end()const{return {graph,edges->end(),edges->end()};}
    std::size_t size()const{return count;}
};
}
