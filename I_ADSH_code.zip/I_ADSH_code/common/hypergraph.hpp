#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace iadsh {

using Capacity = std::int64_t;

enum class RewardPolicy {
    WWW,   // WWW'24-aligned: two reward units per active hyperedge.
    Rank   // Rank-scaled ablation: one reward unit per pin.
};

struct Hyperedge {
    std::vector<int> pins;
    bool active = true;
};

class Hypergraph {
public:
    int n = 0;
    std::vector<Hyperedge> edges;
    std::vector<char> is_anchor;
    std::vector<char> is_reference;

    void validate() const;
    std::vector<Capacity> degrees() const;
    std::vector<Capacity> penalties() const;
    Capacity edge_reward(std::size_t edge_id, RewardPolicy policy) const;
    Capacity total_reward(RewardPolicy policy) const;
    std::size_t active_edge_count() const;
    std::size_t active_pin_count() const;

    int insert_edge(std::vector<int> pins);
    void erase_edge(int edge_id);
    void restore_edge(int edge_id);
};

Hypergraph load_hypergraph(const std::string& path);
void save_hypergraph(const Hypergraph& graph, const std::string& path);
RewardPolicy parse_reward_policy(const std::string& value);
std::string reward_policy_name(RewardPolicy policy);

}  // namespace iadsh
