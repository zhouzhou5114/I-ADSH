#pragma once
#include "hypergraph.hpp"
#include <map>
#include <sstream>
#include <string>
#include <vector>

namespace iadsh::io {
using Id = std::int64_t;
struct Input {
    Hypergraph graph;
    std::vector<Id> external;
    std::map<Id, int> internal;
    std::vector<int> reference, anchors;
};
std::vector<std::string> lines(const std::string&);
std::vector<Id> ids(std::istringstream&);
int vertex(const Input&, Id);
Input load(const std::string& graph_file, const std::string& query_file, std::size_t query_index);
void print(const std::string& algorithm, const Input&, const std::vector<int>& answer,
           int level, std::size_t step, int edge_id = -1);
}  // namespace iadsh::io
