#pragma once

#include "hypergraph.hpp"

#include <array>
#include <vector>

namespace iadsh {

struct CeilBalanceBankToken {
    int edge = -1;
    int token = -1;
};

// Query-independent data shared by the integer and WWW'24 local solvers.
// It is built once per hypergraph and never inspects R or A.
struct QueryGraphIndex {
    explicit QueryGraphIndex(
        const Hypergraph& graph,
        bool build_ceil_balance = false);

    std::vector<std::vector<int>> incident_edges;
    std::vector<Capacity> degree;
    std::vector<double> fractional_degree;
    std::vector<int> active_edges;

    // Optional query-independent Ceil-Balance orientation.  Building it in
    // the same edge/pin pass as the incidence index avoids a second full-graph
    // scan for shared-index workloads.  WWW'24-only callers leave it disabled.
    bool ceil_balance_ready = false;
    std::vector<std::array<int, 2>> base_token_owner;
    std::vector<std::array<int, 2>> base_bank_ordinal;
    std::vector<Capacity> base_vertex_load;
    std::vector<int> base_held_head;
    std::vector<int> base_held_edge;
    std::vector<int> base_held_next;
    std::vector<CeilBalanceBankToken> base_bank_tokens;
};

}  // namespace iadsh
