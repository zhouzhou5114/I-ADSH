#pragma once
#include <algorithm>
#include <cmath>
#include <limits>
#include <queue>
#include <stdexcept>
#include <vector>

namespace iadsh::hgv_detail {
constexpr double FlowEpsilon = 1e-12;

class DoubleDinic {
public:
    struct Edge {
        int to;
        int reverse;
        double residual;
    };

    explicit DoubleDinic(int nodes)
        : graph_(static_cast<std::size_t>(nodes)),
          level_(static_cast<std::size_t>(nodes)),
          next_(static_cast<std::size_t>(nodes)) {
        if (nodes <= 0) throw std::runtime_error("real flow graph must contain nodes");
    }

    void add_edge(int from, int to, double capacity) {
        if (!(capacity >= 0.0) || !std::isfinite(capacity)) {
            throw std::runtime_error("invalid real flow capacity");
        }
        const int forward = static_cast<int>(graph_.at(static_cast<std::size_t>(from)).size());
        const int reverse = static_cast<int>(graph_.at(static_cast<std::size_t>(to)).size());
        graph_[static_cast<std::size_t>(from)].push_back({to, reverse, capacity});
        graph_[static_cast<std::size_t>(to)].push_back({from, forward, 0.0});
    }

    double max_flow(int source, int sink) {
        double total = 0.0;
        while (build_levels(source, sink)) {
            std::fill(next_.begin(), next_.end(), 0);
            while (true) {
                const double sent = send(source, sink, std::numeric_limits<double>::max() / 8.0);
                if (sent <= FlowEpsilon) break;
                total += sent;
            }
        }
        return total;
    }

    std::vector<char> source_side(int source) const {
        std::vector<char> seen(graph_.size(), 0);
        std::queue<int> queue;
        seen[static_cast<std::size_t>(source)] = 1;
        queue.push(source);
        while (!queue.empty()) {
            const int node = queue.front();
            queue.pop();
            for (const auto& edge : graph_[static_cast<std::size_t>(node)]) {
                if (edge.residual <= FlowEpsilon || seen[static_cast<std::size_t>(edge.to)]) continue;
                seen[static_cast<std::size_t>(edge.to)] = 1;
                queue.push(edge.to);
            }
        }
        return seen;
    }

private:
    bool build_levels(int source, int sink) {
        std::fill(level_.begin(), level_.end(), -1);
        std::queue<int> queue;
        level_[static_cast<std::size_t>(source)] = 0;
        queue.push(source);
        while (!queue.empty()) {
            const int node = queue.front();
            queue.pop();
            for (const auto& edge : graph_[static_cast<std::size_t>(node)]) {
                if (edge.residual <= FlowEpsilon ||
                    level_[static_cast<std::size_t>(edge.to)] >= 0) continue;
                level_[static_cast<std::size_t>(edge.to)] =
                    level_[static_cast<std::size_t>(node)] + 1;
                queue.push(edge.to);
            }
        }
        return level_[static_cast<std::size_t>(sink)] >= 0;
    }

    double send(int node, int sink, double pushed) {
        if (node == sink || pushed <= FlowEpsilon) return pushed;
        auto& cursor = next_[static_cast<std::size_t>(node)];
        while (cursor < static_cast<int>(graph_[static_cast<std::size_t>(node)].size())) {
            auto& edge = graph_[static_cast<std::size_t>(node)][static_cast<std::size_t>(cursor)];
            if (edge.residual > FlowEpsilon &&
                level_[static_cast<std::size_t>(edge.to)] ==
                    level_[static_cast<std::size_t>(node)] + 1) {
                const double sent = send(edge.to, sink, std::min(pushed, edge.residual));
                if (sent > FlowEpsilon) {
                    edge.residual -= sent;
                    graph_[static_cast<std::size_t>(edge.to)]
                          [static_cast<std::size_t>(edge.reverse)].residual += sent;
                    return sent;
                }
            }
            ++cursor;
        }
        return 0.0;
    }

    std::vector<std::vector<Edge>> graph_;
    std::vector<int> level_;
    std::vector<int> next_;
};

}  // namespace iadsh::hgv_detail
