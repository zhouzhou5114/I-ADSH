#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build bin
CXX="${CXX:-g++}"
FLAGS=(-std=c++17 -O3 -DNDEBUG -Icommon -Ialgorithms)
OBJECTS=()
for source in common/*.cpp algorithms/*.cpp main.cpp; do
    object="build/${source%.cpp}.o"
    mkdir -p "$(dirname "$object")"
    "$CXX" "${FLAGS[@]}" -c "$source" -o "$object"
    OBJECTS+=("$object")
done
"$CXX" "${FLAGS[@]}" "${OBJECTS[@]}" -o bin/iadsh
echo "Built bin/iadsh"
