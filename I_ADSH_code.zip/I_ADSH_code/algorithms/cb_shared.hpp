#pragma once
#include "cb.hpp"
#include "score.hpp"

namespace iadsh {
bool validate_orientation(
    const Hypergraph&, RewardPolicy, const Orientation&, std::string* error = nullptr);
bool orientation_feasible(
    const Hypergraph&, RewardPolicy, int alpha, const Orientation&, std::string* error = nullptr);
namespace closure_detail {
inline Capacity ceil_div(Capacity a, Capacity b) {
    if (b <= 0) throw std::runtime_error("invalid denominator");
    return a >= 0 ? (a + b - 1) / b : -((-a) / b);
}
}  // namespace closure_detail
}  // namespace iadsh
