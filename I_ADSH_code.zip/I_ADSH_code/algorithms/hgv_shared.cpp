#include "hgv_shared.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <functional>
#include <limits>
#include <memory>
#include <queue>
#include <sstream>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>


namespace iadsh {

namespace hgv_detail {
FlowStep www24_flow_step(
    const Hypergraph& graph,
    const Www24Index& index,
    const std::vector<int>& vertices,
    const std::vector<int>& edges,
    double beta) {
#ifdef PROFILE_ACCESS
    std::size_t network_pins = 0;
    for (int e : edges) network_pins += graph.edges[e].pins.size();
    measure::network(vertices.size(), edges.size(), network_pins);
#endif
    std::unordered_map<int, int> local_id;
    local_id.reserve(vertices.size() * 2 + 1);
    for (int i = 0; i < static_cast<int>(vertices.size()); ++i) {
        local_id.emplace(vertices[static_cast<std::size_t>(i)], i);
    }

    int auxiliary_count = 0;
    for (int edge_id : edges) {
        measure::edge(edge_id);
        if (graph.edges[static_cast<std::size_t>(edge_id)].pins.size() > 2) {
            ++auxiliary_count;
        }
    }
    const int source = static_cast<int>(vertices.size()) + auxiliary_count;
    const int sink = source + 1;
    DoubleDinic flow(sink + 1);
    FlowStep result;

    double finite_bound = static_cast<double>(edges.size()) + 1.0;
    for (int v : vertices) {
        measure::vertex(v);
        finite_bound += index.fractional(v)
            + index.vertex_penalty(graph, v) + std::abs(beta) + 1.0;
    }
    const double infinity = std::max(1.0, 4.0 * finite_bound);

    for (int v : vertices) {
        measure::vertex(v);
        const int node = local_id.at(v);
        const double source_capacity = index.fractional(v);
        const double sink_capacity = index.vertex_penalty(graph, v) + beta;
        if (source_capacity > FlowEpsilon) {
            flow.add_edge(source, node, source_capacity);
            ++result.arcs;
        }
        if (sink_capacity > FlowEpsilon) {
            flow.add_edge(node, sink, sink_capacity);
            ++result.arcs;
        }
        if (graph.is_anchor[static_cast<std::size_t>(v)]) {
            flow.add_edge(source, node, infinity);
            ++result.arcs;
        }
    }

    int auxiliary = static_cast<int>(vertices.size());
    for (int edge_id : edges) {
        measure::edge(edge_id);
        const auto& pins = graph.edges[static_cast<std::size_t>(edge_id)].pins;
        if (pins.size() == 2) {
            measure::pin(edge_id,pins[0]); measure::pin(edge_id,pins[1]);
            const int u = local_id.at(pins[0]);
            const int v = local_id.at(pins[1]);
            flow.add_edge(u, v, 0.5);
            flow.add_edge(v, u, 0.5);
            result.arcs += 2;
        } else {
            const double share = 1.0 / static_cast<double>(pins.size());
            for (int v : pins) {
                measure::pin(edge_id,v);
                const int node = local_id.at(v);
                flow.add_edge(node, auxiliary, share);
                flow.add_edge(auxiliary, node, infinity);
                result.arcs += 2;
            }
            ++auxiliary;
        }
    }

    flow.max_flow(source, sink);
    const auto source_side = flow.source_side(source);
    for (int v : vertices) {
        measure::vertex(v);
        if (source_side[static_cast<std::size_t>(local_id.at(v))]) result.set.push_back(v);
    }
    std::sort(result.set.begin(), result.set.end());
    if (!result.set.empty()) {
        double numerator_value = 0.0;
        for (int edge_id : edges) {
        measure::edge(edge_id);
            bool inside = true;
            for (int v :
                 graph.edges[static_cast<std::size_t>(edge_id)].pins) {
                measure::pin(edge_id,v);
                const auto found = local_id.find(v);
                if (found == local_id.end() ||
                    !source_side[static_cast<std::size_t>(found->second)]) {
                    inside = false;
                    break;
                }
            }
            if (inside) numerator_value += 1.0;
        }
        for (int v : result.set) {
            numerator_value -= index.vertex_penalty(graph, v);
        }
        result.density =
            numerator_value / static_cast<double>(result.set.size());
    }
    return result;
}
}  // namespace hgv_detail

namespace {
void prepare_www24_query_index(
    const Hypergraph& graph,
    Www24Index& index) {
    if (index.graph_index == nullptr ||
        index.graph_index->incident_edges.size() !=
            static_cast<std::size_t>(graph.n)) {
        throw std::runtime_error("WWW24 graph index does not match hypergraph");
    }
    std::sort(index.reference.begin(), index.reference.end());
    index.reference.erase(
        std::unique(index.reference.begin(), index.reference.end()),
        index.reference.end());
    std::sort(index.anchors.begin(), index.anchors.end());
    index.anchors.erase(
        std::unique(index.anchors.begin(), index.anchors.end()),
        index.anchors.end());
    if (index.reference.empty() || index.anchors.empty()) {
        throw std::runtime_error("WWW24 requires nonempty R and A");
    }
    for (int v : index.reference) {
        measure::vertex(v);
        ++index.prepare_work;
        if (v < 0 || v >= graph.n ||
            !graph.is_reference[static_cast<std::size_t>(v)]) {
            throw std::runtime_error(
                "WWW24 reference vector and hypergraph marks disagree");
        }
    }
    for (int v : index.anchors) {
        measure::vertex(v);
        ++index.prepare_work;
        if (!std::binary_search(
                index.reference.begin(), index.reference.end(), v) ||
            !graph.is_anchor[static_cast<std::size_t>(v)]) {
            throw std::runtime_error(
                "WWW24 anchor vector and hypergraph marks disagree");
        }
    }

    std::vector<int> candidates;
    for (int v : index.reference) {
        measure::vertex(v);
        const auto& incident = index.incident(v);
        candidates.insert(candidates.end(), incident.begin(), incident.end());
        index.prepare_work += incident.size();
    }
    std::sort(candidates.begin(), candidates.end());
    candidates.erase(
        std::unique(candidates.begin(), candidates.end()), candidates.end());
    for (int edge_id : candidates) {
        measure::edge(edge_id);
        bool inside = true;
        for (int v : graph.edges[static_cast<std::size_t>(edge_id)].pins) {
            measure::pin(edge_id,v);
            ++index.prepare_work;
            if (!graph.is_reference[static_cast<std::size_t>(v)]) {
                inside = false;
                break;
            }
        }
        if (inside) ++index.reference_internal_edges;
    }
}
}  // namespace

Www24Index::Www24Index(const Hypergraph& graph)
    : owned_graph_index(std::make_shared<QueryGraphIndex>(graph)),
      graph_index(owned_graph_index.get()) {
    graph.validate();
    for (int v = 0; v < graph.n; ++v) {
        if (graph.is_reference[static_cast<std::size_t>(v)]) {
            reference.push_back(v);
        }
        if (graph.is_anchor[static_cast<std::size_t>(v)]) anchors.push_back(v);
    }
    input_graph = &graph;
    prepare_www24_query_index(graph, *this);
}

Www24Index::Www24Index(
    const Hypergraph& graph,
    const QueryGraphIndex& supplied_graph_index,
    std::vector<int> supplied_reference,
    std::vector<int> supplied_anchors)
    : graph_index(&supplied_graph_index),
      reference(std::move(supplied_reference)),
      anchors(std::move(supplied_anchors)) {
    // The supplied static graph index validated structure at construction.
    // Keep sparse A/R validation in prepare_www24_query_index inside query time.
    input_graph = &graph;
    prepare_www24_query_index(graph, *this);
}

double www24_density(
    const Hypergraph& graph,
    const Www24Index& index,
    const std::vector<int>& set) {
    if (set.empty()) return -std::numeric_limits<double>::infinity();
    std::vector<char> selected(static_cast<std::size_t>(graph.n), 0);
    for (int v : set) {
        if (v < 0 || v >= graph.n) throw std::runtime_error("WWW24 set vertex is out of range");
        selected[static_cast<std::size_t>(v)] = 1;
    }
    for (int anchor : index.anchors) {
        if (!selected[static_cast<std::size_t>(anchor)]) {
            throw std::runtime_error("WWW24 strict-anchor set omitted a mandatory anchor");
        }
    }
    double numerator_value = 0.0;
    for (const auto& edge : graph.edges) {
        if (!edge.active) continue;
        bool inside = true;
        for (int v : edge.pins) {
            if (!selected[static_cast<std::size_t>(v)]) {
                inside = false;
                break;
            }
        }
        if (inside) numerator_value += 1.0;
    }
    for (int v : set) numerator_value -= index.vertex_penalty(graph, v);
    return numerator_value / static_cast<double>(set.size());
}

}  // namespace iadsh
