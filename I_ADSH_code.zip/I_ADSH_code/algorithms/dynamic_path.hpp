#pragma once
#include "state.hpp"

namespace iadsh {
DynamicSearchState initialize_dynamic_all_closures(const Hypergraph&, std::vector<int> anchors);
DynamicSearchUpdateResult update_dynamic_all_closures(
    const Hypergraph&, DynamicSearchState&, int edge, bool insertion);
}  // namespace iadsh
