#include "cb_shared.hpp"
#include "profile.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <functional>
#include <limits>
#include <memory>
#include <queue>
#include <sstream>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>


namespace iadsh {

using closure_detail::ceil_div;

// Local maximum-excess search: sparse query corrections and residual closures.

SearchResult lazy_batched_ceil_balance_local_all_closures(
    const Hypergraph& graph,
    const CeilBalanceQueryState& query,
    std::size_t work_cap) {
    if (query.static_index == nullptr ||
        query.static_index->graph_index == nullptr ||
        query.static_index->base_token_owner.size() != graph.edges.size() ||
        query.static_index->graph_index->degree.size() !=
            static_cast<std::size_t>(graph.n)) {
        throw std::runtime_error(
            "Lazy-Batched Ceil-Balance index does not match the hypergraph");
    }
    const auto& static_index = *query.static_index;
    const auto& graph_index = *static_index.graph_index;

    SearchResult result;
    result.best_set = query.reference.empty() ? query.anchors : query.reference;
    if (result.best_set.empty() || query.anchors.empty()) {
        throw std::runtime_error(
            "Lazy-Batched Ceil-Balance requires a nonempty seed set");
    }
    result.balance_seed_level = static_cast<int>(ceil_div(
        2 * query.reference_internal_edges,
        static_cast<Capacity>(result.best_set.size())));
    result.best_level = result.balance_seed_level;

    const int bank_base = graph.n;
    const int bank_count = static_cast<int>(query.anchors.size());
    const std::size_t base_bank_count = static_index.base_bank_tokens.size();
    const std::size_t bank_token_count =
        base_bank_count + query.extra_bank_edges.size();
    auto canonical_bank_load = [&](int slot) {
        const Capacity quotient = static_cast<Capacity>(
            bank_token_count / static_cast<std::size_t>(bank_count));
        const std::size_t remainder =
            bank_token_count % static_cast<std::size_t>(bank_count);
        return quotient +
            (static_cast<std::size_t>(slot) < remainder ? 1 : 0);
    };
    Capacity initial_upper = 0;
    for (int slot = 0; slot < bank_count; ++slot) {
        initial_upper = std::max(initial_upper, canonical_bank_load(slot));
    }
    result.balance_initial_upper = static_cast<int>(initial_upper);
    int certified_level = initial_upper <= result.balance_seed_level
        ? result.balance_seed_level : -1;
    bool zero_roots_initialized=false;
    std::vector<int> zero_fixed;
    std::unordered_set<int> closed_owners;
    closed_owners.reserve(256);

    auto fallback = [&]() -> SearchResult {
        throw std::runtime_error(
            "all-closures prototype exceeded its work budget or made no progress");
    };
    if (work_cap == 0) return fallback();

    bool over_guard = false;
    auto add_work = [&](std::size_t amount = 1) {
        if (result.local_work >
            work_cap - std::min(work_cap, amount)) {
            result.local_work =
                work_cap == std::numeric_limits<std::size_t>::max()
                ? result.local_work + amount
                : work_cap + 1;
        } else {
            result.local_work += amount;
        }
        if (result.local_work > work_cap) over_guard = true;
    };

    std::unordered_map<int, Capacity> load_delta;
    std::unordered_map<int, std::array<int, 2>> changed_owner;
    std::unordered_map<int, std::vector<int>> dynamic_extra_held;
    load_delta.reserve(256);
    changed_owner.reserve(256);
    dynamic_extra_held.reserve(256);

    auto canonical_load = [&](int owner) {
        if (owner < graph.n) {
            Capacity value =
                static_index.base_vertex_load[
                    static_cast<std::size_t>(owner)];
            const auto found = query.vertex_load_delta.find(owner);
            if (found != query.vertex_load_delta.end()) value += found->second;
            return value;
        }
        return canonical_bank_load(owner - bank_base);
    };
    auto current_load = [&](int owner) {
        measure::vertex(owner);
        Capacity value = canonical_load(owner);
        const auto found = load_delta.find(owner);
        if (found != load_delta.end()) value += found->second;
        return value;
    };
    auto adjusted_load = [&](int owner) {
        const Capacity offset = owner < graph.n &&
                !graph.is_reference[static_cast<std::size_t>(owner)]
            ? graph_index.degree[static_cast<std::size_t>(owner)]
            : 0;
        return current_load(owner) - offset;
    };
    auto canonical_token_owners = [&](int edge_id) {
        measure::edge(edge_id);
        const auto overridden = query.owner_override.find(edge_id);
        if (overridden != query.owner_override.end()) {
            for (int v : overridden->second) measure::pin(edge_id, v);
            return overridden->second;
        }
        std::array<int, 2> owners =
            static_index.base_token_owner[
                static_cast<std::size_t>(edge_id)];
        const auto& ordinals =
            static_index.base_bank_ordinal[
                static_cast<std::size_t>(edge_id)];
        for (int token = 0; token < 2; ++token) {
            const std::size_t position = static_cast<std::size_t>(token);
            if (owners[position] == -1) {
                owners[position] = bank_base +
                    ordinals[position] % bank_count;
            }
        }
        for (int v : owners) measure::pin(edge_id, v);
        return owners;
    };
    auto token_owners = [&](int edge_id) {
        const auto found = changed_owner.find(edge_id);
        if (found != changed_owner.end()) {
            for (int v : found->second) measure::pin(edge_id, v);
            return found->second;
        }
        return canonical_token_owners(edge_id);
    };
    auto current_count = [&](int edge_id, int owner) {
        Capacity count = 0;
        for (int held : token_owners(edge_id)) {
            if (held == owner) ++count;
        }
        return count;
    };

    using HeapItem = std::pair<Capacity, int>;
    std::priority_queue<HeapItem> maxima;
    for (int slot = 0; slot < bank_count; ++slot) {
        const int owner = bank_base + slot;
        maxima.push({adjusted_load(owner), owner});
    }
    auto current_maximum = [&]() {
        while (!maxima.empty()) {
            const auto [key, owner] = maxima.top();
            if (!closed_owners.count(owner) && key == adjusted_load(owner)) {
                return maxima.top();
            }
            maxima.pop();
        }
        return HeapItem{0, -1};
    };

    struct Parent {
        int owner = -1;
        int edge = -1;
    };
    struct PathStep {
        int edge = -1;
        int from = -1;
        int to = -1;
    };

    std::unordered_set<int> touched;
    touched.reserve(512);
    while (true) {
        const HeapItem maximum = current_maximum();
        const Capacity upper = maximum.first;
        const int root = maximum.second;
        if (certified_level < 0 &&
            (root < 0 || upper <= result.balance_seed_level)) {
            certified_level = result.balance_seed_level;
        }
        if (certified_level == 0 && !zero_roots_initialized) {
            // At k=0 the k-1 boundary also has zero-load mandatory roots.
            // Discover them globally. A zero-load root has no outgoing held
            // token, so its singleton closure needs no BFS or hash record.
            zero_roots_initialized=true;++result.fallback_calls;
            for(int owner=0;owner<graph.n;++owner)if(!graph.is_anchor[owner]&&adjusted_load(owner)==0){
                if(current_load(owner)==0)zero_fixed.push_back(owner);
                else maxima.push({0,owner});
            }
            for(int slot=0;slot<bank_count;++slot)if(current_load(bank_base+slot)==0)closed_owners.insert(bank_base+slot);
            continue;
        }
        if (certified_level >= 0 &&
            (root < 0 || upper < certified_level)) {
            result.best_level = certified_level;
            result.best_set = query.anchors;
            result.best_set.insert(result.best_set.end(),zero_fixed.begin(),zero_fixed.end());
            for (int owner : closed_owners) {
                if (owner < graph.n && !graph.is_anchor[owner]) {
                    result.best_set.push_back(owner);
                }
            }
            std::sort(result.best_set.begin(), result.best_set.end());
            result.best_set.erase(std::unique(result.best_set.begin(), result.best_set.end()),
                                  result.best_set.end());
            result.touched_edges = touched.size();
            return result;
        }
        if (certified_level >= 0 && upper > certified_level) {
            throw std::runtime_error("maximum load exceeded the certified level");
        }

        ++result.balance_searches;
        std::unordered_map<int, Parent> parent;
        std::unordered_set<int> seen_edges;
        std::vector<int> reached;
        std::vector<int> queue;
        std::vector<int> targets;
        parent.reserve(256);
        seen_edges.reserve(512);
        reached.reserve(256);
        queue.reserve(256);
        targets.reserve(64);
        parent.emplace(root, Parent{});
        reached.push_back(root);
        queue.push_back(root);
        std::size_t queue_head = 0;
        bool bank_slots_exposed = false;
        // A full reachable closure is necessary only when no improving owner
        // exists.  Once several targets have been found, continuing the BFS
        // can turn a strongly-local repair into a graph-wide scan (notably on
        // Stack Overflow tag graphs).  This bounded blocking batch keeps the
        // number of targets proportional to |A| while still amortizing one
        // BFS over multiple reversals.
        const std::size_t target_cap = std::max<std::size_t>(
            8,
            std::min<std::size_t>(
                64, 4 * static_cast<std::size_t>(bank_count)));
        auto batch_ready = [&]() {
            return targets.size() >= target_cap;
        };

        auto expose_owner = [&](int from, int edge_id, int owner) {
            measure::vertex(owner);
            if (owner < graph.n &&
                graph.is_anchor[static_cast<std::size_t>(owner)]) {
                return;
            }
            if(zero_roots_initialized && owner<graph.n && current_load(owner)==0 && adjusted_load(owner)==0)return;
            add_work();
            if (over_guard || closed_owners.count(owner) ||
                parent.find(owner) != parent.end()) return;
            parent.emplace(owner, Parent{from, edge_id});
            reached.push_back(owner);
            if (adjusted_load(owner) <= upper - 2) {
                targets.push_back(owner);
            } else {
                queue.push_back(owner);
            }
        };

        auto expose_held_edge = [&](int owner, int edge_id) {
            if (batch_ready()) return;
            measure::edge(edge_id);
            measure::pin(edge_id, owner);
            add_work();
            if (over_guard || edge_id < 0 ||
                edge_id >= static_cast<int>(graph.edges.size()) ||
                !graph.edges[static_cast<std::size_t>(edge_id)].active ||
                current_count(edge_id, owner) <= 0) {
                return;
            }
            if (!seen_edges.insert(edge_id).second) return;
            touched.insert(edge_id);
            if (!bank_slots_exposed) {
                bank_slots_exposed = true;
                for (int slot = 0; slot < bank_count; ++slot) {
                    ++result.bank_slot_scans;
                    expose_owner(owner, edge_id, bank_base + slot);
                    if (over_guard || batch_ready()) break;
                }
            }
            if (over_guard || batch_ready()) return;
            for (int v :
                 graph.edges[static_cast<std::size_t>(edge_id)].pins) {
                measure::pin(edge_id, v);
                expose_owner(owner, edge_id, v);
                if (over_guard || batch_ready()) break;
            }
        };

        auto enumerate_held = [&](int owner) {
            measure::vertex(owner);
            if (owner < graph.n) {
                for (int link = static_index.base_held_head[
                         static_cast<std::size_t>(owner)];
                     link >= 0;
                     link = static_index.base_held_next[
                         static_cast<std::size_t>(link)]) {
                    expose_held_edge(
                        owner,
                        static_index.base_held_edge[
                            static_cast<std::size_t>(link)]);
                    if (over_guard || batch_ready()) return;
                }
                const auto query_extra = query.extra_held_edges.find(owner);
                if (query_extra != query.extra_held_edges.end()) {
                    for (int edge_id : query_extra->second) {
                        expose_held_edge(owner, edge_id);
                        if (over_guard || batch_ready()) return;
                    }
                }
            } else {
                const std::size_t slot =
                    static_cast<std::size_t>(owner - bank_base);
                for (std::size_t position = slot;
                     position < base_bank_count;
                     position += static_cast<std::size_t>(bank_count)) {
                    expose_held_edge(
                        owner,
                        static_index.base_bank_tokens[position].edge);
                    if (over_guard || batch_ready()) return;
                }
                const std::size_t base_remainder =
                    base_bank_count %
                    static_cast<std::size_t>(bank_count);
                const std::size_t first_extra =
                    (slot + static_cast<std::size_t>(bank_count) -
                     base_remainder) %
                    static_cast<std::size_t>(bank_count);
                for (std::size_t position = first_extra;
                     position < query.extra_bank_edges.size();
                     position += static_cast<std::size_t>(bank_count)) {
                    expose_held_edge(
                        owner, query.extra_bank_edges[position]);
                    if (over_guard || batch_ready()) return;
                }
            }
            const auto dynamic_extra = dynamic_extra_held.find(owner);
            if (dynamic_extra != dynamic_extra_held.end()) {
                for (int edge_id : dynamic_extra->second) {
                    expose_held_edge(owner, edge_id);
                    if (over_guard || batch_ready()) return;
                }
            }
        };

        while (queue_head < queue.size() && !over_guard && !batch_ready()) {
            enumerate_held(queue[queue_head++]);
        }

        result.max_local_vertices =
            std::max(result.max_local_vertices, reached.size());
        result.max_local_edges =
            std::max(result.max_local_edges, seen_edges.size());
        if (over_guard) {
            result.touched_edges = touched.size();
            return fallback();
        }

        if (targets.empty()) {
            if (certified_level < 0) certified_level = static_cast<int>(upper);
            if (upper != certified_level) {
                throw std::runtime_error("failed closure has inconsistent level");
            }
            closed_owners.insert(reached.begin(), reached.end());
            continue;
        }

        std::sort(
            targets.begin(), targets.end(), [&](int left, int right) {
                const Capacity left_load = adjusted_load(left);
                const Capacity right_load = adjusted_load(right);
                if (left_load != right_load) return left_load < right_load;
                return left < right;
            });
        std::size_t moved_in_batch = 0;
        for (int target : targets) {
            const Capacity difference =
                adjusted_load(root) - adjusted_load(target);
            if (difference < 2) continue;
            std::vector<PathStep> path;
            int to = target;
            while (to != root) {
                const Parent link = parent.at(to);
                if (link.owner < 0 || link.edge < 0) {
                    throw std::runtime_error(
                        "Lazy-Batched Ceil-Balance path reconstruction failed");
                }
                path.push_back({link.edge, link.owner, to});
                to = link.owner;
            }
            Capacity amount = std::max<Capacity>(1, difference / 2);
            for (const auto& step : path) {
                measure::pin(step.edge, step.from);
                measure::pin(step.edge, step.to);
                amount = std::min(
                    amount, current_count(step.edge, step.from));
            }
            if (amount <= 0) continue;

            for (const auto& step : path) {
                measure::pin(step.edge, step.from);
                measure::pin(step.edge, step.to);
                const Capacity before_to =
                    current_count(step.edge, step.to);
                auto inserted = changed_owner.try_emplace(
                    step.edge, canonical_token_owners(step.edge));
                auto& owners = inserted.first->second;
                Capacity remaining = amount;
                for (int& owner : owners) {
                    if (remaining > 0 && owner == step.from) {
                        owner = step.to;
                        --remaining;
                    }
                }
                if (remaining != 0) {
                    throw std::runtime_error(
                        "Lazy-Batched token ownership became inconsistent");
                }
                load_delta[step.from] -= amount;
                load_delta[step.to] += amount;
                if (before_to == 0) {
                    dynamic_extra_held[step.to].push_back(step.edge);
                }
            }
            moved_in_batch += static_cast<std::size_t>(amount);
            result.augmentations += static_cast<std::size_t>(amount);
            ++result.balance_paths;
            maxima.push({adjusted_load(root), root});
            maxima.push({adjusted_load(target), target});
        }
        if (moved_in_batch == 0) {
            result.touched_edges = touched.size();
            return fallback();
        }
    }
}

}  // namespace iadsh
