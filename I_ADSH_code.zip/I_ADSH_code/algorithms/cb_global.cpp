#include "cb_shared.hpp"
#include "profile.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <functional>
#include <limits>
#include <memory>
#include <queue>
#include <sstream>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>


namespace iadsh {

using closure_detail::ceil_div;

// Global maximum-excess search: full owner state and bounded blocking paths.

SearchResult batched_ceil_balance_global_all_closures(
    const Hypergraph& graph) {
    std::vector<int> anchors;
    for (int v = 0; v < graph.n; ++v) if (graph.is_anchor[v]) anchors.push_back(v);
    if (anchors.empty()) throw std::runtime_error("Global needs anchors");
    const int bank_base = graph.n;
    const int bank_count = static_cast<int>(anchors.size());
    const int owner_count = graph.n + bank_count;

    SearchResult result;
    for (int v = 0; v < graph.n; ++v) {
        if (graph.is_reference[static_cast<std::size_t>(v)]) {
            result.best_set.push_back(v);
        }
    }

    // Unlike the local solver, the Global physical plan materializes the
    // complete current two-token orientation and held-edge index once.  It
    // still leaves the much larger edge-to-allowed-owner residual side
    // implicit and exposes pins only when a blocking BFS reaches an edge.
    std::vector<std::array<int, 2>> current_owner(
        graph.edges.size(), std::array<int, 2>{-2, -2});
    std::vector<Capacity> load(
        static_cast<std::size_t>(owner_count), 0);
    std::vector<std::vector<int>> held_edges(
        static_cast<std::size_t>(owner_count));
    std::vector<Capacity> degree(static_cast<std::size_t>(graph.n), 0);
    std::vector<int> active_edges;
    Capacity reference_internal_edges = 0;
    std::size_t bank_ordinal = 0;
    for (int edge_id = 0; edge_id < static_cast<int>(graph.edges.size()); ++edge_id) {
        const auto& edge = graph.edges[static_cast<std::size_t>(edge_id)];
        if (!edge.active) continue;
        active_edges.push_back(edge_id);
        std::array<int, 2> owners{-1, -1};
        int assigned = 0;
        bool inside = true;
        for (int v : edge.pins) {
            ++degree[static_cast<std::size_t>(v)];
            if (!graph.is_reference[static_cast<std::size_t>(v)]) {
                inside = false;
                if (assigned < 2) owners[static_cast<std::size_t>(assigned++)] = v;
            }
        }
        if (inside) ++reference_internal_edges;
        for (int token = assigned; token < 2; ++token) {
            owners[static_cast<std::size_t>(token)] = bank_base +
                static_cast<int>(bank_ordinal++ % static_cast<std::size_t>(bank_count));
        }
        current_owner[static_cast<std::size_t>(edge_id)] = owners;
        for (int token = 0; token < 2; ++token) {
            const int owner = owners[static_cast<std::size_t>(token)];
            if (owner < 0 || owner >= owner_count) {
                throw std::runtime_error(
                    "Batched Ceil-Balance-Global owner is out of range");
            }
            ++load[static_cast<std::size_t>(owner)];
            if (token == 0 || owner != owners[0]) {
                held_edges[static_cast<std::size_t>(owner)]
                    .push_back(edge_id);
            }
        }
    }
    result.balance_seed_level = static_cast<int>(ceil_div(
        2 * reference_internal_edges,
        static_cast<Capacity>(result.best_set.size())));
    result.best_level = result.balance_seed_level;

    auto adjusted_load = [&](int owner) {
        const Capacity offset = owner < graph.n &&
                !graph.is_reference[static_cast<std::size_t>(owner)]
            ? degree[static_cast<std::size_t>(owner)]
            : 0;
        return load[static_cast<std::size_t>(owner)] - offset;
    };
    auto current_count = [&](int edge_id, int owner) {
        Capacity count = 0;
        for (int held :
             current_owner[static_cast<std::size_t>(edge_id)]) {
            if (held == owner) ++count;
        }
        return count;
    };

    std::vector<char> touched(graph.edges.size(), 0);

    Capacity initial_upper = 0;
    for (int slot = 0; slot < bank_count; ++slot) {
        initial_upper = std::max(
            initial_upper, adjusted_load(bank_base + slot));
    }
    result.balance_initial_upper = static_cast<int>(initial_upper);
    int certified_level = initial_upper <= result.balance_seed_level
        ? result.balance_seed_level : -1;
    std::vector<char> closed(owner_count, 0);
    bool zero_roots_initialized=false;

    using HeapItem = std::pair<Capacity, int>;
    std::priority_queue<HeapItem> maxima;
    for (int slot = 0; slot < bank_count; ++slot) {
        const int owner = bank_base + slot;
        maxima.push({adjusted_load(owner), owner});
    }
    auto current_maximum = [&]() {
        while (!maxima.empty()) {
            const auto [key, owner] = maxima.top();
            if (!closed[owner] && key == adjusted_load(owner)) return maxima.top();
            maxima.pop();
        }
        return HeapItem{0, -1};
    };

    std::vector<int> owner_epoch(
        static_cast<std::size_t>(owner_count), 0);
    std::vector<int> parent_owner(
        static_cast<std::size_t>(owner_count), -1);
    std::vector<int> parent_edge(
        static_cast<std::size_t>(owner_count), -1);
    std::vector<int> edge_epoch(graph.edges.size(), 0);
    int search_epoch = 0;

    struct PathStep {
        int edge = -1;
        int from = -1;
        int to = -1;
    };

    while (true) {
        const HeapItem maximum = current_maximum();
        const Capacity upper = maximum.first;
        const int root = maximum.second;
        if (certified_level < 0 && (root < 0 || upper <= result.balance_seed_level))
            certified_level = result.balance_seed_level;
        if(certified_level==0&&!zero_roots_initialized){
            zero_roots_initialized=true;++result.fallback_calls;
            for(int owner=0;owner<graph.n;++owner)if(!graph.is_anchor[owner]&&adjusted_load(owner)==0){
                if(load[owner]==0)closed[owner]=1;else maxima.push({0,owner});
            }
            for(int slot=0;slot<bank_count;++slot)if(load[bank_base+slot]==0)closed[bank_base+slot]=1;
            continue;
        }
        if (certified_level >= 0 && (root < 0 || upper < certified_level)) {
            result.best_level = certified_level;
            result.best_set = anchors;
            for (int owner = 0; owner < graph.n; ++owner)
                if (closed[owner] && !graph.is_anchor[owner]) result.best_set.push_back(owner);
            std::sort(result.best_set.begin(),result.best_set.end());
            return result;
        }
        if (certified_level >= 0 && upper > certified_level)
            throw std::runtime_error("Global exceeded certified optimum");

        if (search_epoch == std::numeric_limits<int>::max()) {
            std::fill(owner_epoch.begin(), owner_epoch.end(), 0);
            std::fill(edge_epoch.begin(), edge_epoch.end(), 0);
            search_epoch = 0;
        }
        ++search_epoch;
        ++result.balance_searches;

        std::vector<int> reached;
        std::vector<int> queue;
        std::vector<int> targets;
        reached.reserve(256);
        queue.reserve(256);
        targets.reserve(64);
        owner_epoch[static_cast<std::size_t>(root)] = search_epoch;
        parent_owner[static_cast<std::size_t>(root)] = -1;
        parent_edge[static_cast<std::size_t>(root)] = -1;
        reached.push_back(root);
        queue.push_back(root);
        std::size_t queue_head = 0;
        std::size_t reached_edge_count = 0;
        bool bank_slots_exposed = false;
        const std::size_t target_cap = std::max<std::size_t>(
            8,
            std::min<std::size_t>(
                64, 4 * static_cast<std::size_t>(bank_count)));
        auto batch_ready = [&]() {
            return targets.size() >= target_cap;
        };

        auto expose_owner = [&](int from, int edge_id, int owner) {
            if (owner < 0 || owner >= owner_count) return;
            if (owner < graph.n &&
                graph.is_anchor[static_cast<std::size_t>(owner)]) {
                return;
            }
            ++result.local_work;
            if (closed[owner] || owner_epoch[static_cast<std::size_t>(owner)] ==
                search_epoch) {
                return;
            }
            owner_epoch[static_cast<std::size_t>(owner)] = search_epoch;
            parent_owner[static_cast<std::size_t>(owner)] = from;
            parent_edge[static_cast<std::size_t>(owner)] = edge_id;
            reached.push_back(owner);
            if (adjusted_load(owner) <= upper - 2) {
                targets.push_back(owner);
            } else {
                queue.push_back(owner);
            }
        };

        auto expose_held_edge = [&](int owner, int edge_id) {
            if (batch_ready() || edge_id < 0 ||
                edge_id >= static_cast<int>(graph.edges.size()) ||
                !graph.edges[static_cast<std::size_t>(edge_id)].active) {
                return;
            }
            ++result.local_work;
            if (current_count(edge_id, owner) <= 0 ||
                edge_epoch[static_cast<std::size_t>(edge_id)] ==
                    search_epoch) {
                return;
            }
            edge_epoch[static_cast<std::size_t>(edge_id)] = search_epoch;
            ++reached_edge_count;
            if (!touched[static_cast<std::size_t>(edge_id)]) {
                touched[static_cast<std::size_t>(edge_id)] = 1;
                ++result.touched_edges;
            }
            if (!bank_slots_exposed) {
                bank_slots_exposed = true;
                for (int slot = 0; slot < bank_count; ++slot) {
                    ++result.bank_slot_scans;
                    expose_owner(
                        owner, edge_id, bank_base + slot);
                    if (batch_ready()) break;
                }
            }
            if (batch_ready()) return;
            for (int v :
                 graph.edges[static_cast<std::size_t>(edge_id)].pins) {
                expose_owner(owner, edge_id, v);
                if (batch_ready()) break;
            }
        };

        while (queue_head < queue.size() && !batch_ready()) {
            const int owner = queue[queue_head++];
            for (int edge_id :
                 held_edges[static_cast<std::size_t>(owner)]) {
                expose_held_edge(owner, edge_id);
                if (batch_ready()) break;
            }
        }

        result.max_local_vertices =
            std::max(result.max_local_vertices, reached.size());
        result.max_local_edges =
            std::max(result.max_local_edges, reached_edge_count);

        if (targets.empty()) {
            if (certified_level < 0) certified_level = static_cast<int>(upper);
            if (upper != certified_level) throw std::runtime_error("Global closure level mismatch");
            for (int owner : reached) closed[owner] = 1;
            continue;
        }

        std::sort(
            targets.begin(), targets.end(), [&](int left, int right) {
                const Capacity left_load = adjusted_load(left);
                const Capacity right_load = adjusted_load(right);
                if (left_load != right_load) {
                    return left_load < right_load;
                }
                return left < right;
            });

        std::size_t moved_in_batch = 0;
        for (int target : targets) {
            const Capacity difference =
                adjusted_load(root) - adjusted_load(target);
            if (difference < 2) continue;
            std::vector<PathStep> path;
            int to = target;
            while (to != root) {
                const int from =
                    parent_owner[static_cast<std::size_t>(to)];
                const int edge =
                    parent_edge[static_cast<std::size_t>(to)];
                if (from < 0 || edge < 0) {
                    throw std::runtime_error(
                        "Batched Ceil-Balance-Global path reconstruction failed");
                }
                path.push_back({edge, from, to});
                to = from;
            }

            Capacity amount = std::max<Capacity>(1, difference / 2);
            for (const auto& step : path) {
                amount = std::min(
                    amount, current_count(step.edge, step.from));
            }
            if (amount <= 0) continue;

            for (const auto& step : path) {
                const Capacity before_to =
                    current_count(step.edge, step.to);
                auto& owners =
                    current_owner[static_cast<std::size_t>(step.edge)];
                Capacity remaining = amount;
                for (int& owner : owners) {
                    if (remaining > 0 && owner == step.from) {
                        owner = step.to;
                        --remaining;
                    }
                }
                if (remaining != 0) {
                    throw std::runtime_error(
                        "Batched Ceil-Balance-Global token ownership became inconsistent");
                }
                load[static_cast<std::size_t>(step.from)] -= amount;
                load[static_cast<std::size_t>(step.to)] += amount;
                if (before_to == 0) {
                    held_edges[static_cast<std::size_t>(step.to)]
                        .push_back(step.edge);
                }
            }
            moved_in_batch += static_cast<std::size_t>(amount);
            result.augmentations += static_cast<std::size_t>(amount);
            ++result.balance_paths;
            maxima.push({adjusted_load(root), root});
            maxima.push({adjusted_load(target), target});
        }
        if (moved_in_batch == 0) {
            throw std::runtime_error(
                "Batched Ceil-Balance-Global found no usable blocking path");
        }
    }
}

// Preserve the upper orientation certificate for Dynamic-Path initialization.

CertifiedSearchResult batched_ceil_balance_global(
    const Hypergraph& graph,
    bool retain_upper_certificate) {
    graph.validate();
    const auto anchors = anchor_set(graph);
    const int bank_base = graph.n;
    const int bank_count = static_cast<int>(anchors.size());
    const int owner_count = graph.n + bank_count;

    CertifiedSearchResult result;
    for (int v = 0; v < graph.n; ++v) {
        if (graph.is_reference[static_cast<std::size_t>(v)]) {
            result.best_set.push_back(v);
        }
    }

    // Unlike the local solver, the Global physical plan materializes the
    // complete current two-token orientation and held-edge index once.  It
    // still leaves the much larger edge-to-allowed-owner residual side
    // implicit and exposes pins only when a blocking BFS reaches an edge.
    std::vector<std::array<int, 2>> current_owner(
        graph.edges.size(), std::array<int, 2>{-2, -2});
    std::vector<Capacity> load(
        static_cast<std::size_t>(owner_count), 0);
    std::vector<std::vector<int>> held_edges(
        static_cast<std::size_t>(owner_count));
    std::vector<Capacity> degree(static_cast<std::size_t>(graph.n), 0);
    std::vector<int> active_edges;
    Capacity reference_internal_edges = 0;
    std::size_t bank_ordinal = 0;
    for (int edge_id = 0; edge_id < static_cast<int>(graph.edges.size()); ++edge_id) {
        const auto& edge = graph.edges[static_cast<std::size_t>(edge_id)];
        if (!edge.active) continue;
        active_edges.push_back(edge_id);
        std::array<int, 2> owners{-1, -1};
        int assigned = 0;
        bool inside = true;
        for (int v : edge.pins) {
            ++degree[static_cast<std::size_t>(v)];
            if (!graph.is_reference[static_cast<std::size_t>(v)]) {
                inside = false;
                if (assigned < 2) owners[static_cast<std::size_t>(assigned++)] = v;
            }
        }
        if (inside) ++reference_internal_edges;
        for (int token = assigned; token < 2; ++token) {
            owners[static_cast<std::size_t>(token)] = bank_base +
                static_cast<int>(bank_ordinal++ % static_cast<std::size_t>(bank_count));
        }
        current_owner[static_cast<std::size_t>(edge_id)] = owners;
        for (int token = 0; token < 2; ++token) {
            const int owner = owners[static_cast<std::size_t>(token)];
            if (owner < 0 || owner >= owner_count) {
                throw std::runtime_error(
                    "Batched Ceil-Balance-Global owner is out of range");
            }
            ++load[static_cast<std::size_t>(owner)];
            if (token == 0 || owner != owners[0]) {
                held_edges[static_cast<std::size_t>(owner)]
                    .push_back(edge_id);
            }
        }
    }
    result.balance_seed_level = static_cast<int>(detail::ceil_div(
        2 * reference_internal_edges,
        static_cast<Capacity>(result.best_set.size())));
    result.best_level = result.balance_seed_level;

    auto adjusted_load = [&](int owner) {
        const Capacity offset = owner < graph.n &&
                !graph.is_reference[static_cast<std::size_t>(owner)]
            ? degree[static_cast<std::size_t>(owner)]
            : 0;
        return load[static_cast<std::size_t>(owner)] - offset;
    };
    auto current_count = [&](int edge_id, int owner) {
        Capacity count = 0;
        for (int held :
             current_owner[static_cast<std::size_t>(edge_id)]) {
            if (held == owner) ++count;
        }
        return count;
    };

    std::vector<char> touched(graph.edges.size(), 0);
    auto finish = [&]() {
        if (!retain_upper_certificate) return;
        result.upper_certificate.x.resize(graph.edges.size());
        for (int edge_id : active_edges) {
            const auto& owners =
                current_owner[static_cast<std::size_t>(edge_id)];
            for (int owner : owners) {
                const int compressed =
                    owner >= bank_base ? AnchorBank : owner;
                ++result.upper_certificate
                      .x[static_cast<std::size_t>(edge_id)][compressed];
            }
        }
        std::string error;
        if (!orientation_feasible(
                graph,
                RewardPolicy::WWW,
                result.best_level + 1,
                result.upper_certificate,
                &error)) {
            throw std::runtime_error(
                "Batched Ceil-Balance-Global upper certificate is invalid: " +
                error);
        }
    };

    Capacity initial_upper = 0;
    for (int slot = 0; slot < bank_count; ++slot) {
        initial_upper = std::max(
            initial_upper, adjusted_load(bank_base + slot));
    }
    result.balance_initial_upper = static_cast<int>(initial_upper);
    if (initial_upper <= result.balance_seed_level) {
        result.balance_seed_certificate = true;
        finish();
        return result;
    }

    using HeapItem = std::pair<Capacity, int>;
    std::priority_queue<HeapItem> maxima;
    for (int slot = 0; slot < bank_count; ++slot) {
        const int owner = bank_base + slot;
        maxima.push({adjusted_load(owner), owner});
    }
    auto current_maximum = [&]() {
        while (!maxima.empty()) {
            const auto [key, owner] = maxima.top();
            if (key == adjusted_load(owner)) return maxima.top();
            maxima.pop();
        }
        return HeapItem{0, -1};
    };

    std::vector<int> owner_epoch(
        static_cast<std::size_t>(owner_count), 0);
    std::vector<int> parent_owner(
        static_cast<std::size_t>(owner_count), -1);
    std::vector<int> parent_edge(
        static_cast<std::size_t>(owner_count), -1);
    std::vector<int> edge_epoch(graph.edges.size(), 0);
    int search_epoch = 0;

    struct PathStep {
        int edge = -1;
        int from = -1;
        int to = -1;
    };

    while (true) {
        const HeapItem maximum = current_maximum();
        const Capacity upper = maximum.first;
        const int root = maximum.second;
        if (root < 0 || upper <= result.balance_seed_level) {
            result.best_level = result.balance_seed_level;
            result.balance_seed_certificate = true;
            finish();
            return result;
        }

        if (search_epoch == std::numeric_limits<int>::max()) {
            std::fill(owner_epoch.begin(), owner_epoch.end(), 0);
            std::fill(edge_epoch.begin(), edge_epoch.end(), 0);
            search_epoch = 0;
        }
        ++search_epoch;
        ++result.balance_searches;

        std::vector<int> reached;
        std::vector<int> queue;
        std::vector<int> targets;
        reached.reserve(256);
        queue.reserve(256);
        targets.reserve(64);
        owner_epoch[static_cast<std::size_t>(root)] = search_epoch;
        parent_owner[static_cast<std::size_t>(root)] = -1;
        parent_edge[static_cast<std::size_t>(root)] = -1;
        reached.push_back(root);
        queue.push_back(root);
        std::size_t queue_head = 0;
        std::size_t reached_edge_count = 0;
        bool bank_slots_exposed = false;
        const std::size_t target_cap = std::max<std::size_t>(
            8,
            std::min<std::size_t>(
                64, 4 * static_cast<std::size_t>(bank_count)));
        auto batch_ready = [&]() {
            return targets.size() >= target_cap;
        };

        auto expose_owner = [&](int from, int edge_id, int owner) {
            if (owner < 0 || owner >= owner_count) return;
            if (owner < graph.n &&
                graph.is_anchor[static_cast<std::size_t>(owner)]) {
                return;
            }
            ++result.local_work;
            if (owner_epoch[static_cast<std::size_t>(owner)] ==
                search_epoch) {
                return;
            }
            owner_epoch[static_cast<std::size_t>(owner)] = search_epoch;
            parent_owner[static_cast<std::size_t>(owner)] = from;
            parent_edge[static_cast<std::size_t>(owner)] = edge_id;
            reached.push_back(owner);
            if (adjusted_load(owner) <= upper - 2) {
                targets.push_back(owner);
            } else {
                queue.push_back(owner);
            }
        };

        auto expose_held_edge = [&](int owner, int edge_id) {
            if (batch_ready() || edge_id < 0 ||
                edge_id >= static_cast<int>(graph.edges.size()) ||
                !graph.edges[static_cast<std::size_t>(edge_id)].active) {
                return;
            }
            ++result.local_work;
            if (current_count(edge_id, owner) <= 0 ||
                edge_epoch[static_cast<std::size_t>(edge_id)] ==
                    search_epoch) {
                return;
            }
            edge_epoch[static_cast<std::size_t>(edge_id)] = search_epoch;
            ++reached_edge_count;
            if (!touched[static_cast<std::size_t>(edge_id)]) {
                touched[static_cast<std::size_t>(edge_id)] = 1;
                ++result.touched_edges;
            }
            if (!bank_slots_exposed) {
                bank_slots_exposed = true;
                for (int slot = 0; slot < bank_count; ++slot) {
                    ++result.bank_slot_scans;
                    expose_owner(
                        owner, edge_id, bank_base + slot);
                    if (batch_ready()) break;
                }
            }
            if (batch_ready()) return;
            for (int v :
                 graph.edges[static_cast<std::size_t>(edge_id)].pins) {
                expose_owner(owner, edge_id, v);
                if (batch_ready()) break;
            }
        };

        while (queue_head < queue.size() && !batch_ready()) {
            const int owner = queue[queue_head++];
            for (int edge_id :
                 held_edges[static_cast<std::size_t>(owner)]) {
                expose_held_edge(owner, edge_id);
                if (batch_ready()) break;
            }
        }

        result.max_local_vertices =
            std::max(result.max_local_vertices, reached.size());
        result.max_local_edges =
            std::max(result.max_local_edges, reached_edge_count);

        if (targets.empty()) {
            // The search was not batch-truncated, so the reached region is a
            // complete residual closure and is the exact lower witness.
            result.best_level = static_cast<int>(upper);
            result.best_set = anchors;
            for (int owner : reached) {
                if (owner < graph.n &&
                    !graph.is_anchor[static_cast<std::size_t>(owner)]) {
                    result.best_set.push_back(owner);
                }
            }
            std::sort(result.best_set.begin(), result.best_set.end());
            result.best_set.erase(
                std::unique(
                    result.best_set.begin(), result.best_set.end()),
                result.best_set.end());
            if (integer_level(
                    graph, result.best_set, RewardPolicy::WWW) <
                result.best_level) {
                throw std::runtime_error(
                    "Batched Ceil-Balance-Global closure is not a witness");
            }
            finish();
            return result;
        }

        std::sort(
            targets.begin(), targets.end(), [&](int left, int right) {
                const Capacity left_load = adjusted_load(left);
                const Capacity right_load = adjusted_load(right);
                if (left_load != right_load) {
                    return left_load < right_load;
                }
                return left < right;
            });

        std::size_t moved_in_batch = 0;
        for (int target : targets) {
            const Capacity difference =
                adjusted_load(root) - adjusted_load(target);
            if (difference < 2) continue;
            std::vector<PathStep> path;
            int to = target;
            while (to != root) {
                const int from =
                    parent_owner[static_cast<std::size_t>(to)];
                const int edge =
                    parent_edge[static_cast<std::size_t>(to)];
                if (from < 0 || edge < 0) {
                    throw std::runtime_error(
                        "Batched Ceil-Balance-Global path reconstruction failed");
                }
                path.push_back({edge, from, to});
                to = from;
            }

            Capacity amount = std::max<Capacity>(1, difference / 2);
            for (const auto& step : path) {
                amount = std::min(
                    amount, current_count(step.edge, step.from));
            }
            if (amount <= 0) continue;

            for (const auto& step : path) {
                const Capacity before_to =
                    current_count(step.edge, step.to);
                auto& owners =
                    current_owner[static_cast<std::size_t>(step.edge)];
                Capacity remaining = amount;
                for (int& owner : owners) {
                    if (remaining > 0 && owner == step.from) {
                        owner = step.to;
                        --remaining;
                    }
                }
                if (remaining != 0) {
                    throw std::runtime_error(
                        "Batched Ceil-Balance-Global token ownership became inconsistent");
                }
                load[static_cast<std::size_t>(step.from)] -= amount;
                load[static_cast<std::size_t>(step.to)] += amount;
                if (before_to == 0) {
                    held_edges[static_cast<std::size_t>(step.to)]
                        .push_back(step.edge);
                }
            }
            moved_in_batch += static_cast<std::size_t>(amount);
            result.augmentations += static_cast<std::size_t>(amount);
            ++result.balance_paths;
            maxima.push({adjusted_load(root), root});
            maxima.push({adjusted_load(target), target});
        }
        if (moved_in_batch == 0) {
            throw std::runtime_error(
                "Batched Ceil-Balance-Global found no usable blocking path");
        }
    }
}

}  // namespace iadsh
