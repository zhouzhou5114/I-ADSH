#include "hgv_shared.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <functional>
#include <limits>
#include <memory>
#include <queue>
#include <sstream>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>


namespace iadsh {

using namespace hgv_detail;

namespace {
FlowStep www24_local_step(
    const Hypergraph& graph,
    const Www24Index& index,
    const std::vector<int>& extra_seeds,
    double beta,
    Www24Result* statistics) {
    std::unordered_set<int> explored(index.reference.begin(), index.reference.end());
    explored.insert(extra_seeds.begin(), extra_seeds.end());
    std::unordered_set<int> local(explored);

    auto expand_around = [&](const std::vector<int>& additions) {
        for (int v : additions) {
            for (int edge_id : index.incident(v)) {
                for (int u : graph.edges[static_cast<std::size_t>(edge_id)].pins) {
                    measure::pin(edge_id,u); local.insert(u);
                }
            }
        }
    };
    expand_around(index.reference);
    // Refinement may add integer-witness seeds outside the reference set.
    // Include their incident pins before materializing the first regional
    // network, otherwise an edge selected through a seed can miss a pin.
    expand_around(extra_seeds);

    FlowStep final_step;
    while (true) {
        std::unordered_set<int> edge_set;
        for (int v : explored) {
            for (int edge_id : index.incident(v)) {
                edge_set.insert(edge_id);
            }
        }
        std::vector<int> vertices(local.begin(), local.end());
        std::vector<int> edges(edge_set.begin(), edge_set.end());
        std::sort(vertices.begin(), vertices.end());
        std::sort(edges.begin(), edges.end());

        final_step = www24_flow_step(graph, index, vertices, edges, beta);
        ++statistics->flow_calls;
        statistics->network_arcs += final_step.arcs;
        statistics->max_local_vertices =
            std::max(statistics->max_local_vertices, vertices.size());
        statistics->max_local_edges =
            std::max(statistics->max_local_edges, edges.size());

        std::vector<int> additions;
        for (int v : final_step.set) {
            if (explored.find(v) == explored.end()) additions.push_back(v);
        }
        if (additions.empty()) return final_step;
        for (int v : additions) explored.insert(v);
        expand_around(additions);
        ++statistics->local_expansions;
    }
}
}  // namespace

// Both variants expand the reference region through the same local flow step.

Www24Result www24_local(
    const Hypergraph& graph,
    const Www24Index& index,
    double tolerance) {
    std::vector<int> initial_set = index.reference;
    if (initial_set.empty()) initial_set = index.anchors;
    return density_improvement(
        graph, index, initial_set, std::numeric_limits<double>::infinity(), tolerance,
        [&](double beta, Www24Result* statistics) {
            return www24_local_step(graph, index, {}, beta, statistics);
        });
}

Www24Result www24_local_integer_stop(
    const Hypergraph& graph,
    const Www24Index& index,
    double tolerance) {
    std::vector<int> initial_set = index.reference;
    if (initial_set.empty()) initial_set = index.anchors;
    return integer_ceiling_improvement(
        graph, index, initial_set, tolerance,
        [&](double beta, Www24Result* statistics) {
            return www24_local_step(
                graph, index, {}, beta, statistics);
        });
}

}  // namespace iadsh
