#pragma once

#include "hypergraph.hpp"
#include "active_incidence.hpp"
#include "profile.hpp"
#include "query_index.hpp"

#include <cstddef>
#include <memory>
#include <vector>

namespace iadsh {

// Query-independent incidence and terminal-capacity data used by the C++ port
// of Huang, Gleich, and Veldt (WWW 2024), specialized to epsilon = 1.
struct Www24Index {
    explicit Www24Index(const Hypergraph& graph);
    Www24Index(
        const Hypergraph& graph,
        const QueryGraphIndex& graph_index,
        std::vector<int> reference,
        std::vector<int> anchors);

    std::shared_ptr<const QueryGraphIndex> owned_graph_index;
    const QueryGraphIndex* graph_index = nullptr;
    const Hypergraph* input_graph = nullptr;
    std::vector<int> reference;
    std::vector<int> anchors;
    std::size_t reference_internal_edges = 0;
    std::size_t prepare_work = 0;

    ActiveIncidence incident(int v) const {
        measure::vertex(v);
#ifdef PROFILE_ACCESS
        for (int e : graph_index->incident_edges[static_cast<std::size_t>(v)]) measure::pin(e,v);
#endif
        return {input_graph,&graph_index->incident_edges[static_cast<std::size_t>(v)],static_cast<std::size_t>(graph_index->degree[v])};
    }
    double fractional(int v) const {
        measure::vertex(v);
        return graph_index->fractional_degree[static_cast<std::size_t>(v)];
    }
    double vertex_penalty(const Hypergraph& graph, int v) const {
        measure::vertex(v);
        return graph.is_reference[static_cast<std::size_t>(v)]
            ? 0.0
            : 0.5 * static_cast<double>(
                  graph_index->degree[static_cast<std::size_t>(v)]);
    }
};

struct Www24Result {
    // Original WWW'24 units:
    // (|E[S]| - 0.5 * Vol(S \ R)) / |S|.
    double density = 0.0;
    double initial_density = 0.0;
    double upper_bound = 0.0;
    std::vector<int> best_set;
    int iterations = 0;
    int flow_calls = 0;
    int local_expansions = 0;
    bool certified_by_upper_bound = false;
    std::size_t network_arcs = 0;
    std::size_t max_local_vertices = 0;
    std::size_t max_local_edges = 0;
};

double www24_density(
    const Hypergraph& graph,
    const Www24Index& index,
    const std::vector<int>& set);

// Direct C++ ports of ADHSG_flow_density_improvement(..., type="global") and
// type="local". Mandatory anchors are added by infinite source arcs; setting a
// singleton anchor recovers the strict-anchor adaptation used in this project.
Www24Result www24_global(
    const Hypergraph& graph,
    const Www24Index& index,
    double tolerance = 1e-10);
Www24Result www24_local(
    const Hypergraph& graph,
    const Www24Index& index,
    double tolerance = 1e-10);

// Fair same-output baselines for the integer ceiling objective.  Starting
// from a level-k witness, they test only the real boundary k/2.  A failed
// improvement certifies that no level-(k+1) solution exists, so refinement
// inside the same ceiling bucket is intentionally skipped.
Www24Result www24_global_integer_stop(
    const Hypergraph& graph,
    const Www24Index& index,
    double tolerance = 1e-10);
Www24Result www24_local_integer_stop(
    const Hypergraph& graph,
    const Www24Index& index,
    double tolerance = 1e-10);

}  // namespace iadsh
