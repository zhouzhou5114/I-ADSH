#include "hgv_shared.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <functional>
#include <limits>
#include <memory>
#include <queue>
#include <sstream>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>


namespace iadsh {

using namespace hgv_detail;

namespace {
std::vector<int> active_edges(const Hypergraph& graph) {
    std::vector<int> result;
    result.reserve(graph.active_edge_count());
    for (int edge_id = 0; edge_id < static_cast<int>(graph.edges.size()); ++edge_id) {
        if (graph.edges[static_cast<std::size_t>(edge_id)].active) result.push_back(edge_id);
    }
    return result;
}

std::vector<int> all_vertices(const Hypergraph& graph) {
    std::vector<int> result(static_cast<std::size_t>(graph.n));
    for (int v = 0; v < graph.n; ++v) result[static_cast<std::size_t>(v)] = v;
    return result;
}
}  // namespace

// Both variants materialize the complete active graph; the shared loop selects
// real density improvement or integer-boundary stopping.

Www24Result www24_global(
    const Hypergraph& graph,
    const Www24Index& index,
    double tolerance) {
    std::vector<int> initial_set = index.reference;
    if (initial_set.empty()) initial_set = index.anchors;
    const auto vertices = all_vertices(graph);
    const auto edges = active_edges(graph);
    return density_improvement(
        graph, index, initial_set, std::numeric_limits<double>::infinity(), tolerance,
        [&](double beta, Www24Result* statistics) {
            auto step = www24_flow_step(graph, index, vertices, edges, beta);
            ++statistics->flow_calls;
            statistics->network_arcs += step.arcs;
            statistics->max_local_vertices = vertices.size();
            statistics->max_local_edges = edges.size();
            return step;
        });
}

Www24Result www24_global_integer_stop(
    const Hypergraph& graph,
    const Www24Index& index,
    double tolerance) {
    std::vector<int> initial_set = index.reference;
    if (initial_set.empty()) initial_set = index.anchors;
    const auto vertices = all_vertices(graph);
    const auto edges = active_edges(graph);
    return integer_ceiling_improvement(
        graph, index, initial_set, tolerance,
        [&](double beta, Www24Result* statistics) {
            auto step =
                www24_flow_step(graph, index, vertices, edges, beta);
            ++statistics->flow_calls;
            statistics->network_arcs += step.arcs;
            statistics->max_local_vertices = vertices.size();
            statistics->max_local_edges = edges.size();
            return step;
        });
}

}  // namespace iadsh
