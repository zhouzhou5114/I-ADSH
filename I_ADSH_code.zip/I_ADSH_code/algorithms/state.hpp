#pragma once

#include "hypergraph.hpp"
#include "query_index.hpp"

#include <array>
#include <cstdint>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace iadsh {

constexpr int AnchorBank = -1;

// A WWW edge has exactly two reward units, so its orientation can involve at
// most two owners.  Keeping those entries inline avoids one unordered-map
// allocation per active edge and, critically, avoids first-touch allocations
// for fresh temporal insertions.  Rank-scaled ablations may need more than two
// owners; they transparently spill to a vector while preserving the small map
// interface used by the solvers.
class OwnerAssignments {
public:
    using value_type = std::pair<int, Capacity>;
    using iterator = value_type*;
    using const_iterator = const value_type*;

    OwnerAssignments() = default;

    OwnerAssignments(const OwnerAssignments& other)
        : inline_entries_(other.inline_entries_),
          inline_size_(other.inline_size_) {
        if (other.overflow_) {
            overflow_ = std::make_unique<std::vector<value_type>>(
                *other.overflow_);
        }
    }

    OwnerAssignments& operator=(const OwnerAssignments& other) {
        if (this == &other) return *this;
        inline_entries_ = other.inline_entries_;
        inline_size_ = other.inline_size_;
        if (other.overflow_) {
            overflow_ = std::make_unique<std::vector<value_type>>(
                *other.overflow_);
        } else {
            overflow_.reset();
        }
        return *this;
    }

    OwnerAssignments(OwnerAssignments&&) noexcept = default;
    OwnerAssignments& operator=(OwnerAssignments&&) noexcept = default;

    iterator begin() {
        return overflow_ ? overflow_->data() : inline_entries_.data();
    }
    iterator end() { return begin() + size(); }
    const_iterator begin() const {
        return overflow_ ? overflow_->data() : inline_entries_.data();
    }
    const_iterator end() const { return begin() + size(); }

    bool empty() const { return size() == 0; }
    std::size_t size() const {
        return overflow_ ? overflow_->size() : inline_size_;
    }

    iterator find(int owner) {
        for (iterator it = begin(); it != end(); ++it) {
            if (it->first == owner) return it;
        }
        return end();
    }
    const_iterator find(int owner) const {
        for (const_iterator it = begin(); it != end(); ++it) {
            if (it->first == owner) return it;
        }
        return end();
    }

    Capacity& operator[](int owner) {
        iterator existing = find(owner);
        if (existing != end()) return existing->second;
        if (!overflow_ && inline_size_ < inline_entries_.size()) {
            value_type& entry = inline_entries_[inline_size_++];
            entry = {owner, 0};
            return entry.second;
        }
        if (!overflow_) {
            overflow_ = std::make_unique<std::vector<value_type>>();
            overflow_->reserve(4);
            overflow_->insert(
                overflow_->end(),
                inline_entries_.begin(),
                inline_entries_.begin() + inline_size_);
            inline_size_ = 0;
        }
        overflow_->push_back({owner, 0});
        return overflow_->back().second;
    }

    Capacity& at(int owner) {
        iterator existing = find(owner);
        if (existing == end()) {
            throw std::out_of_range("owner assignment is absent");
        }
        return existing->second;
    }
    const Capacity& at(int owner) const {
        const_iterator existing = find(owner);
        if (existing == end()) {
            throw std::out_of_range("owner assignment is absent");
        }
        return existing->second;
    }

    iterator erase(iterator position) {
        if (overflow_) {
            const std::size_t index = static_cast<std::size_t>(
                position - overflow_->data());
            overflow_->erase(overflow_->begin() + index);
            return overflow_->data() + index;
        }
        const std::size_t index = static_cast<std::size_t>(
            position - inline_entries_.data());
        for (std::size_t i = index + 1; i < inline_size_; ++i) {
            inline_entries_[i - 1] = inline_entries_[i];
        }
        --inline_size_;
        return inline_entries_.data() + index;
    }

    void clear() {
        if (overflow_) {
            overflow_->clear();
        } else {
            inline_size_ = 0;
        }
    }

private:
    std::array<value_type, 2> inline_entries_{};
    std::unique_ptr<std::vector<value_type>> overflow_;
    std::size_t inline_size_ = 0;
};

struct Orientation {
    // x[e][owner] is the compressed number of edge-e reward units assigned to owner.
    // owner == AnchorBank denotes the global mandatory-anchor bank.
    std::vector<OwnerAssignments> x;
};

struct ReOrientResult {
    bool repaired = false;
    Capacity routed_overload = 0;
    Capacity total_overload = 0;
    std::size_t residual_arcs = 0;
    std::size_t augmentations = 0;
    Orientation orientation;
    // When repair fails, the final residual reachable region directly gives
    // an anchor-containing level-alpha witness.
    std::vector<int> witness;
};

struct SearchResult {
    int best_level = 0;
    std::vector<int> best_set;
    int oracle_calls = 0;
    std::size_t local_work = 0;
    std::size_t touched_edges = 0;
    std::size_t augmentations = 0;
    int fallback_calls = 0;
    std::size_t regional_flow_calls = 0;
    std::size_t regional_expansions = 0;
    std::size_t max_local_vertices = 0;
    std::size_t max_local_edges = 0;
    int balance_seed_level = 0;
    int balance_initial_upper = 0;
    std::size_t balance_searches = 0;
    std::size_t balance_paths = 0;
    std::size_t bank_slot_scans = 0;
    bool balance_seed_certificate = false;
};

// A static optimum together with the feasible level-(k+1) orientation needed
// to initialize exact dynamic maintenance.  Static benchmarks may omit the
// orientation to avoid materializing an output they do not consume.
struct CertifiedSearchResult : SearchResult {
    Orientation upper_certificate;
};

// The genuinely query-independent part of Lazy-Batched Ceil-Balance.  Its
// two-token orientation ignores R; a query only stores sparse corrections
// for base owners that become forbidden because they lie in R.
struct CeilBalanceStaticIndex {
    CeilBalanceStaticIndex(
        const Hypergraph& graph,
        const QueryGraphIndex& graph_index);

    const QueryGraphIndex* graph_index = nullptr;
    const std::vector<std::array<int, 2>>& base_token_owner;
    const std::vector<std::array<int, 2>>& base_bank_ordinal;
    const std::vector<Capacity>& base_vertex_load;
    const std::vector<int>& base_held_head;
    const std::vector<int>& base_held_edge;
    const std::vector<int>& base_held_next;
    const std::vector<CeilBalanceBankToken>& base_bank_tokens;
};

// Sparse state rebuilt for each (R,A) query.  It never copies graph-wide
// incidence, degree, load, held-edge, or token-owner arrays.
struct CeilBalanceQueryState {
    CeilBalanceQueryState(
        const Hypergraph& graph,
        const CeilBalanceStaticIndex& static_index,
        std::vector<int> reference,
        std::vector<int> anchors);

    const CeilBalanceStaticIndex* static_index = nullptr;
    std::vector<int> reference;
    std::vector<int> anchors;
    Capacity reference_internal_edges = 0;
    std::unordered_map<int, std::array<int, 2>> owner_override;
    std::unordered_map<int, Capacity> vertex_load_delta;
    std::unordered_map<int, std::vector<int>> extra_held_edges;
    std::vector<int> extra_bank_edges;
    std::size_t prepare_work = 0;
};

// Exact dynamic state for the canonical WWW policy.  The witness proves that
// best_level is attainable, while upper_certificate proves that
// best_level + 1 is unattainable.
struct DynamicSearchState {
    int best_level = 0;
    std::vector<int> witness;
    Orientation upper_certificate;

    // Persistent auxiliary state for genuinely incremental maintenance.
    // Ordinary owner v uses slot v and the aggregate anchor bank uses slot n.
    // held_edges may contain stale entries; a residual traversal validates
    // ownership against upper_certificate before following one.
    std::vector<Capacity> penalty;
    std::vector<Capacity> owner_load;
    // Immutable initialization lists plus a global append-only linked store
    // avoid copying a high-degree owner's full held-edge vector or allocating
    // one small vector per newly touched owner.
    std::vector<std::vector<int>> held_edges;
    std::vector<int> extra_held_head;
    std::vector<int> extra_held_edge;
    std::vector<int> extra_held_next;
    int anchor_count = 0;

    // Cached score of the current lower witness.  A single edge update changes
    // it in O(rank(edge)); it is rebuilt only when a failed repair returns a
    // new witness.
    std::vector<char> witness_membership;
    Capacity witness_numerator = 0;

    // Timestamped residual-search workspace avoids allocating and clearing
    // O(n+m) parent arrays after every update.
    std::uint64_t visit_epoch = 0;
    std::vector<std::uint64_t> owner_visit_epoch;
    std::vector<std::uint64_t> edge_visit_epoch;
    std::vector<int> parent_edge_of_owner;
    std::vector<int> parent_owner_of_edge;
    bool auxiliary_initialized = false;
    // Active overload roots at the maximum-excess boundary k-1. Only enabled
    // by the modified dynamic variant; legacy routines retain their behavior.
    int closure_root_level = -1;
    std::unordered_set<int> closure_roots;
    std::vector<int> closure_anchors;
};

struct DynamicSearchUpdateResult {
    DynamicSearchState state;
    int old_level = 0;
    int new_level = 0;
    int static_calls = 0;
    double edge_update_ms = 0.0;
    double boundary_repair_ms = 0.0;
    double transition_ms = 0.0;
    // Repair at the old boundary k+1.
    ReOrientResult boundary_repair;
    // Used only after promotion, to construct the new k+2 no-certificate.
    ReOrientResult promoted_upper_repair;
    // Used only when the old witness disappears.  The already repaired
    // level-(k+1) orientation is rebalanced at level k, avoiding a fresh
    // full-network fixed-level flow.
    ReOrientResult lower_boundary_repair;
};

}  // namespace iadsh
