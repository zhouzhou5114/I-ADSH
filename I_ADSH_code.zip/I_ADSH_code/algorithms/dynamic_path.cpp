#include "dynamic_path.hpp"
#include "cb.hpp"
#include "score.hpp"
#include "profile.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <functional>
#include <limits>
#include <memory>
#include <queue>
#include <sstream>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>


namespace iadsh {

namespace {

int dynamic_owner_slot(const Hypergraph& graph, int owner) {
    return owner == AnchorBank ? graph.n : owner;
}

int dynamic_owner_key(const Hypergraph& graph, int slot) {
    return slot == graph.n ? AnchorBank : slot;
}

void refresh_closure_root(DynamicSearchState& state,int slot) {
    if(state.closure_root_level<0)return;
    if(std::binary_search(state.closure_anchors.begin(),state.closure_anchors.end(),slot))return;
    const int bank=int(state.owner_load.size())-1;
    const Capacity theta=Capacity(state.closure_root_level)-1;
    const Capacity cap=slot==bank?Capacity(state.anchor_count)*theta:state.penalty[slot]+theta;
    if(state.owner_load[slot]>cap)state.closure_roots.insert(slot);
    else state.closure_roots.erase(slot);
}

void dynamic_change_load(
    const Hypergraph& graph,
    DynamicSearchState& state,
    int owner,
    Capacity delta) {
    const int slot = dynamic_owner_slot(graph, owner);
    state.owner_load[static_cast<std::size_t>(slot)] += delta;
    refresh_closure_root(state,slot);
    if (state.owner_load[static_cast<std::size_t>(slot)] < 0) {
        throw std::runtime_error("dynamic owner load became negative");
    }
}

void dynamic_change_penalty(
    DynamicSearchState& state,
    int owner,
    Capacity delta) {
    state.penalty[static_cast<std::size_t>(owner)] += delta;
    refresh_closure_root(state,owner);
    if (state.penalty[static_cast<std::size_t>(owner)] < 0) {
        throw std::runtime_error("dynamic owner penalty became negative");
    }
}

Capacity dynamic_owner_capacity(
    const Hypergraph& graph,
    const DynamicSearchState& state,
    int owner_slot,
    int alpha) {
    const Capacity theta = alpha - 1;
    if (owner_slot == graph.n) {
        return static_cast<Capacity>(state.anchor_count) * theta;
    }
    return state.penalty[static_cast<std::size_t>(owner_slot)] + theta;
}

Capacity dynamic_witness_edge_contribution(
    const Hypergraph& graph,
    const DynamicSearchState& state,
    int edge_id) {
    const auto& edge = graph.edges[static_cast<std::size_t>(edge_id)];
    bool inside = true;
    Capacity outside_reference_volume = 0;
    for (int v : edge.pins) {
        if (!state.witness_membership[static_cast<std::size_t>(v)]) {
            inside = false;
        } else if (!graph.is_reference[static_cast<std::size_t>(v)]) {
            ++outside_reference_volume;
        }
    }
    return (inside ? 2 : 0) - outside_reference_volume;
}

void dynamic_set_witness(
    const Hypergraph& graph,
    DynamicSearchState& state,
    std::vector<int> witness) {
    for (int v : state.witness) {
        state.witness_membership[static_cast<std::size_t>(v)] = 0;
    }
    std::sort(witness.begin(), witness.end());
    witness.erase(std::unique(witness.begin(), witness.end()), witness.end());
    state.witness = std::move(witness);
    for (int v : state.witness) {
        state.witness_membership[static_cast<std::size_t>(v)] = 1;
    }
    state.witness_numerator = numerator(
        graph, state.witness_membership, RewardPolicy::WWW);
}

int dynamic_cached_witness_level(
    const DynamicSearchState& state) {
    if (state.witness.empty()) {
        return std::numeric_limits<int>::min();
    }
    return static_cast<int>(detail::ceil_div(
        state.witness_numerator,
        static_cast<Capacity>(state.witness.size())));
}

void initialize_dynamic_auxiliary(
    const Hypergraph& graph,
    DynamicSearchState& state) {
    state.penalty = graph.penalties();
    state.owner_load.assign(static_cast<std::size_t>(graph.n + 1), 0);
    state.held_edges.assign(
        static_cast<std::size_t>(graph.n + 1), {});
    state.extra_held_head.assign(
        static_cast<std::size_t>(graph.n + 1), -1);
    state.extra_held_edge.clear();
    state.extra_held_next.clear();
    const std::size_t extra_reserve =
        std::min<std::size_t>(
            graph.active_pin_count(),
            std::max<std::size_t>(
                4096, graph.active_edge_count() / 8));
    state.extra_held_edge.reserve(extra_reserve);
    state.extra_held_next.reserve(extra_reserve);
    state.anchor_count = 0;
    for (int v = 0; v < graph.n; ++v) {
        if (graph.is_anchor[static_cast<std::size_t>(v)]) {
            ++state.anchor_count;
        }
    }
    for (int edge_id = 0;
         edge_id < static_cast<int>(state.upper_certificate.x.size());
         ++edge_id) {
        for (const auto& item :
             state.upper_certificate.x[static_cast<std::size_t>(edge_id)]) {
            if (item.second <= 0) continue;
            const int slot = dynamic_owner_slot(graph, item.first);
            state.owner_load[static_cast<std::size_t>(slot)] += item.second;
            state.held_edges[static_cast<std::size_t>(slot)]
                .push_back(edge_id);
        }
    }
    state.witness_membership.assign(
        static_cast<std::size_t>(graph.n), 0);
    for (int v : state.witness) {
        state.witness_membership[static_cast<std::size_t>(v)] = 1;
    }
    state.witness_numerator = numerator(
        graph, state.witness_membership, RewardPolicy::WWW);
    state.owner_visit_epoch.assign(
        static_cast<std::size_t>(graph.n + 1), 0);
    state.edge_visit_epoch.assign(graph.edges.size(), 0);
    state.parent_edge_of_owner.assign(
        static_cast<std::size_t>(graph.n + 1), -1);
    state.parent_owner_of_edge.assign(graph.edges.size(), -1);
    state.visit_epoch = 0;
    state.auxiliary_initialized = true;
}

std::vector<int> apply_dynamic_edge_update(
    const Hypergraph& graph,
    DynamicSearchState& state,
    int edge_id,
    bool insertion,
    int boundary_alpha) {
    if (!state.auxiliary_initialized) {
        throw std::runtime_error(
            "dynamic auxiliary state was not initialized");
    }
    if (edge_id < 0 ||
        edge_id >= static_cast<int>(graph.edges.size())) {
        throw std::runtime_error("dynamic affected edge is out of range");
    }
    const auto& edge = graph.edges[static_cast<std::size_t>(edge_id)];
    if (insertion != edge.active) {
        throw std::runtime_error(
            "dynamic update type disagrees with graph edge state");
    }
    std::vector<int> affected_owners{graph.n};
    affected_owners.reserve(edge.pins.size() + 1);
    for (int v : edge.pins) {
        if (!graph.is_anchor[static_cast<std::size_t>(v)]) {
            affected_owners.push_back(v);
        }
    }

    const Capacity witness_delta =
        dynamic_witness_edge_contribution(graph, state, edge_id);
    state.witness_numerator += insertion
        ? witness_delta
        : -witness_delta;

    if (insertion) {
        if (edge_id <
                static_cast<int>(state.upper_certificate.x.size()) &&
            !state.upper_certificate.x[
                static_cast<std::size_t>(edge_id)].empty()) {
            throw std::runtime_error(
                "dynamic insertion edge already owns tokens");
        }
        state.upper_certificate.x.resize(graph.edges.size());
        state.edge_visit_epoch.resize(graph.edges.size(), 0);
        state.parent_owner_of_edge.resize(graph.edges.size(), -1);
        for (int v : edge.pins) {
            if (!graph.is_reference[static_cast<std::size_t>(v)]) {
                dynamic_change_penalty(state, v, 1);
            }
        }

        auto& edge_map =
            state.upper_certificate.x[static_cast<std::size_t>(edge_id)];
        for (int token = 0; token < 2; ++token) {
            int best_owner = AnchorBank;
            Capacity best_after =
                state.owner_load[static_cast<std::size_t>(graph.n)] + 1 -
                dynamic_owner_capacity(
                    graph, state, graph.n, boundary_alpha);
            for (int v : edge.pins) {
                if (graph.is_anchor[static_cast<std::size_t>(v)]) continue;
                const Capacity after =
                    state.owner_load[static_cast<std::size_t>(v)] + 1 -
                    dynamic_owner_capacity(
                        graph, state, v, boundary_alpha);
                if (after < best_after) {
                    best_after = after;
                    best_owner = v;
                }
            }
            const bool newly_held = edge_map.find(best_owner) == edge_map.end();
            ++edge_map[best_owner];
            dynamic_change_load(graph, state, best_owner, 1);
            if (newly_held) {
                const int slot = dynamic_owner_slot(graph, best_owner);
                const int position =
                    static_cast<int>(state.extra_held_edge.size());
                state.extra_held_edge.push_back(edge_id);
                state.extra_held_next.push_back(
                    state.extra_held_head[static_cast<std::size_t>(slot)]);
                state.extra_held_head[static_cast<std::size_t>(slot)] =
                    position;
            }
        }
    } else {
        if (edge_id >=
            static_cast<int>(state.upper_certificate.x.size())) {
            throw std::runtime_error(
                "dynamic deletion certificate has no affected edge");
        }
        auto& edge_map =
            state.upper_certificate.x[static_cast<std::size_t>(edge_id)];
        Capacity removed = 0;
        for (const auto& item : edge_map) {
            dynamic_change_load(graph, state, item.first, -item.second);
            removed += item.second;
        }
        if (removed != 2) {
            throw std::runtime_error(
                "dynamic deletion did not remove two WWW tokens");
        }
        edge_map.clear();
        for (int v : edge.pins) {
            if (!graph.is_reference[static_cast<std::size_t>(v)]) {
                dynamic_change_penalty(state, v, -1);
            }
        }
    }
    std::sort(affected_owners.begin(), affected_owners.end());
    affected_owners.erase(
        std::unique(
            affected_owners.begin(), affected_owners.end()),
        affected_owners.end());
    return affected_owners;
}

ReOrientResult repair_dynamic_state(
    const Hypergraph& graph,
    DynamicSearchState& state,
    int alpha,
    const std::vector<int>* affected_owners = nullptr,
    const std::vector<int>* known_anchors = nullptr) {
    if (alpha < (known_anchors ? 0 : 1)) {
        throw std::runtime_error(
            "incremental dynamic repair requires alpha >= 1");
    }
    ReOrientResult result;
    auto overload = [&](int owner_slot) {
        return std::max<Capacity>(
            0,
            state.owner_load[static_cast<std::size_t>(owner_slot)] -
                dynamic_owner_capacity(
                    graph, state, owner_slot, alpha));
    };
    auto deficit = [&](int owner_slot) {
        return std::max<Capacity>(
            0,
            dynamic_owner_capacity(
                graph, state, owner_slot, alpha) -
                state.owner_load[static_cast<std::size_t>(owner_slot)]);
    };

    std::vector<int> source_candidates;
    if (affected_owners != nullptr) {
        source_candidates = *affected_owners;
    } else {
        source_candidates.reserve(static_cast<std::size_t>(graph.n + 1));
        for (int v = 0; v < graph.n; ++v) {
            if (!graph.is_anchor[static_cast<std::size_t>(v)]) {
                source_candidates.push_back(v);
            }
        }
        source_candidates.push_back(graph.n);
    }
    for (int owner_slot : source_candidates) {
        result.total_overload += overload(owner_slot);
    }
    if (result.total_overload == 0) {
        result.repaired = true;
        return result;
    }

    Capacity remaining = result.total_overload;
    while (remaining > 0) {
        ++state.visit_epoch;
        if (state.visit_epoch == 0) {
            std::fill(
                state.owner_visit_epoch.begin(),
                state.owner_visit_epoch.end(), 0);
            std::fill(
                state.edge_visit_epoch.begin(),
                state.edge_visit_epoch.end(), 0);
            state.visit_epoch = 1;
        }
        const std::uint64_t epoch = state.visit_epoch;
        std::vector<int> queue;
        std::vector<int> reached_owners;
        queue.reserve(64);
        reached_owners.reserve(64);
        auto visit_owner = [&](int owner_slot, int parent_edge) {
            state.owner_visit_epoch[
                static_cast<std::size_t>(owner_slot)] = epoch;
            state.parent_edge_of_owner[
                static_cast<std::size_t>(owner_slot)] = parent_edge;
            queue.push_back(owner_slot);
            reached_owners.push_back(owner_slot);
        };

        for (int owner_slot : source_candidates) {
            if (overload(owner_slot) > 0) {
                visit_owner(owner_slot, -1);
            }
        }

        int target_owner = -1;
        std::size_t queue_head = 0;
        while (queue_head < queue.size() && target_owner < 0) {
            const int owner_slot = queue[queue_head++];
            const int owner_key = dynamic_owner_key(graph, owner_slot);
            auto expose_held_edge = [&](int held_edge) {
                ++result.residual_arcs;
                if (held_edge < 0 ||
                    held_edge >= static_cast<int>(graph.edges.size()) ||
                    !graph.edges[static_cast<std::size_t>(held_edge)].active) {
                    return;
                }
                const auto& edge_map =
                    state.upper_certificate.x[
                        static_cast<std::size_t>(held_edge)];
                const auto held = edge_map.find(owner_key);
                if (held == edge_map.end() || held->second <= 0) return;
                if (state.edge_visit_epoch[
                        static_cast<std::size_t>(held_edge)] == epoch) {
                    return;
                }
                state.edge_visit_epoch[
                    static_cast<std::size_t>(held_edge)] = epoch;
                state.parent_owner_of_edge[
                    static_cast<std::size_t>(held_edge)] = owner_slot;

                auto expose_owner = [&](int next_owner) {
                    ++result.residual_arcs;
                    const int next_slot =
                        dynamic_owner_slot(graph, next_owner);
                    if (state.owner_visit_epoch[
                            static_cast<std::size_t>(next_slot)] == epoch) {
                        return;
                    }
                    state.owner_visit_epoch[
                        static_cast<std::size_t>(next_slot)] = epoch;
                    state.parent_edge_of_owner[
                        static_cast<std::size_t>(next_slot)] = held_edge;
                    reached_owners.push_back(next_slot);
                    if (deficit(next_slot) > 0) {
                        target_owner = next_slot;
                    } else {
                        queue.push_back(next_slot);
                    }
                };

                expose_owner(AnchorBank);
                if (target_owner >= 0) return;
                for (int v :
                     graph.edges[static_cast<std::size_t>(held_edge)].pins) {
                    if (graph.is_anchor[static_cast<std::size_t>(v)]) {
                        continue;
                    }
                    expose_owner(v);
                    if (target_owner >= 0) break;
                }
            };
            for (int held_edge :
                 state.held_edges[static_cast<std::size_t>(owner_slot)]) {
                expose_held_edge(held_edge);
                if (target_owner >= 0) break;
            }
            if (target_owner < 0) {
                int position = state.extra_held_head[
                    static_cast<std::size_t>(owner_slot)];
                while (position >= 0) {
                    expose_held_edge(
                        state.extra_held_edge[
                            static_cast<std::size_t>(position)]);
                    if (target_owner >= 0) break;
                    position = state.extra_held_next[
                        static_cast<std::size_t>(position)];
                }
            }
        }

        if (target_owner < 0) {
            result.witness = known_anchors ? *known_anchors : anchor_set(graph);
            for (int owner_slot : reached_owners) {
                if (owner_slot != graph.n) {
                    result.witness.push_back(owner_slot);
                }
            }
            std::sort(result.witness.begin(), result.witness.end());
            result.witness.erase(
                std::unique(
                    result.witness.begin(), result.witness.end()),
                result.witness.end());
            break;
        }

        struct Transfer {
            int edge_id = -1;
            int from_owner = -1;
            int to_owner = -1;
        };
        std::vector<Transfer> transfers;
        Capacity amount = deficit(target_owner);
        int child_owner = target_owner;
        while (state.parent_edge_of_owner[
                   static_cast<std::size_t>(child_owner)] >= 0) {
            const int transfer_edge =
                state.parent_edge_of_owner[
                    static_cast<std::size_t>(child_owner)];
            const int from_owner =
                state.parent_owner_of_edge[
                    static_cast<std::size_t>(transfer_edge)];
            const int from_key =
                dynamic_owner_key(graph, from_owner);
            const auto& edge_map =
                state.upper_certificate.x[
                    static_cast<std::size_t>(transfer_edge)];
            const auto held = edge_map.find(from_key);
            if (held == edge_map.end() || held->second <= 0) {
                throw std::runtime_error(
                    "dynamic residual parent lost its held token");
            }
            amount = std::min(amount, held->second);
            transfers.push_back(
                {transfer_edge, from_owner, child_owner});
            child_owner = from_owner;
        }
        amount = std::min(amount, overload(child_owner));
        if (amount <= 0) {
            throw std::runtime_error(
                "dynamic repair found a zero-capacity path");
        }

        for (auto iterator = transfers.rbegin();
             iterator != transfers.rend();
             ++iterator) {
            const int from_key =
                dynamic_owner_key(graph, iterator->from_owner);
            const int to_key =
                dynamic_owner_key(graph, iterator->to_owner);
            auto& edge_map =
                state.upper_certificate.x[
                    static_cast<std::size_t>(iterator->edge_id)];
            auto from = edge_map.find(from_key);
            if (from == edge_map.end() || from->second < amount) {
                throw std::runtime_error(
                    "dynamic token transfer exceeded held load");
            }
            from->second -= amount;
            if (from->second == 0) edge_map.erase(from);
            auto to = edge_map.find(to_key);
            const bool newly_held =
                to == edge_map.end() || to->second == 0;
            edge_map[to_key] += amount;
            if (newly_held) {
                const int position =
                    static_cast<int>(state.extra_held_edge.size());
                state.extra_held_edge.push_back(iterator->edge_id);
                state.extra_held_next.push_back(
                    state.extra_held_head[
                        static_cast<std::size_t>(iterator->to_owner)]);
                state.extra_held_head[
                    static_cast<std::size_t>(iterator->to_owner)] =
                    position;
            }
        }
        const int root_key = dynamic_owner_key(graph, child_owner);
        const int target_key = dynamic_owner_key(graph, target_owner);
        dynamic_change_load(graph, state, root_key, -amount);
        dynamic_change_load(graph, state, target_key, amount);
        remaining -= amount;
        result.routed_overload += amount;
        ++result.augmentations;
    }
    result.repaired = remaining == 0;
    return result;
}

void extract_maximum_excess(const Hypergraph& graph,DynamicSearchState& state) {
    if(state.closure_root_level!=state.best_level){
        state.closure_roots.clear();state.closure_root_level=state.best_level;
        for(int slot=0;slot<=graph.n;++slot)refresh_closure_root(state,slot);
    }
    std::vector<int> roots(state.closure_roots.begin(),state.closure_roots.end());
    std::sort(roots.begin(),roots.end());
    const auto cut=repair_dynamic_state(graph,state,state.best_level,&roots,&state.closure_anchors);
    if(cut.repaired || cut.witness.empty())throw std::runtime_error("Modified Path lost its positive maximum excess");
    const Capacity maximum_excess=cut.total_overload-cut.routed_overload;
    for(int v:state.witness)state.witness_membership[v]=0;
    state.witness=cut.witness;
    for(int v:state.witness)state.witness_membership[v]=1;
    state.witness_numerator=maximum_excess+(Capacity(state.best_level)-1)*Capacity(state.witness.size());
}

}  // namespace

DynamicSearchUpdateResult update_dynamic_search_in_place(
    const Hypergraph& graph,
    RewardPolicy policy,
    DynamicSearchState& state,
    int affected_edge,
    bool insertion) {
    if (policy != RewardPolicy::WWW) {
        throw std::runtime_error(
            "exact dynamic level maintenance is defined for policy www");
    }
    if (state.best_level < 0) {
        throw std::runtime_error("negative dynamic best level");
    }
    const int old_level = state.best_level;
    DynamicSearchUpdateResult result;
    result.old_level = old_level;

    const auto edge_update_start =
        std::chrono::steady_clock::now();
    const std::vector<int> affected_owners = apply_dynamic_edge_update(
        graph, state, affected_edge, insertion, old_level + 1);
    const auto boundary_start =
        std::chrono::steady_clock::now();
    result.boundary_repair = repair_dynamic_state(
        graph, state, old_level + 1, &affected_owners);
    const auto transition_start =
        std::chrono::steady_clock::now();

    if (!result.boundary_repair.repaired) {
        state.best_level = old_level + 1;
        dynamic_set_witness(
            graph, state, result.boundary_repair.witness);
        // The failed level-(k+1) repair may have already routed part of the
        // overload.  Raising every capacity by one level and continuing the
        // same sparse repair produces the new level-(k+2) upper certificate
        // without restoring or copying the pre-update orientation.
        result.promoted_upper_repair = repair_dynamic_state(
            graph, state, old_level + 2, &affected_owners);
        if (!result.promoted_upper_repair.repaired) {
            throw std::runtime_error(
                "dynamic promotion could not build its upper certificate");
        }
    } else if (dynamic_cached_witness_level(state) >= old_level) {
        state.best_level = old_level;
    } else if (old_level == 0) {
        state.best_level = 0;
    } else {
        result.lower_boundary_repair = repair_dynamic_state(
            graph, state, old_level);
        ++result.static_calls;
        if (!result.lower_boundary_repair.repaired) {
            state.best_level = old_level;
            dynamic_set_witness(
                graph, state, result.lower_boundary_repair.witness);
        } else {
            state.best_level = old_level - 1;
        }
    }
    result.new_level = state.best_level;
    if (dynamic_cached_witness_level(state) < state.best_level) {
        throw std::runtime_error(
            "dynamic update returned an invalid cached lower witness");
    }
    const auto transition_end =
        std::chrono::steady_clock::now();
    auto duration_ms = [](auto start, auto end) {
        return std::chrono::duration<double, std::milli>(
            end - start).count();
    };
    result.edge_update_ms =
        duration_ms(edge_update_start, boundary_start);
    result.boundary_repair_ms =
        duration_ms(boundary_start, transition_start);
    result.transition_ms =
        duration_ms(transition_start, transition_end);
    return result;
}

DynamicSearchState initialize_dynamic_all_closures(const Hypergraph& graph,std::vector<int> anchors){
    const auto optimum=batched_ceil_balance_global(graph,true);
    DynamicSearchState state;state.best_level=optimum.best_level;
    state.witness=optimum.best_set;state.upper_certificate=optimum.upper_certificate;
    initialize_dynamic_auxiliary(graph,state);
    std::sort(anchors.begin(),anchors.end());state.closure_anchors=std::move(anchors);
    extract_maximum_excess(graph,state);
    return state;
}

DynamicSearchUpdateResult update_dynamic_all_closures(const Hypergraph& graph,DynamicSearchState& state,int edge,bool insertion){
    auto result=update_dynamic_search_in_place(graph,RewardPolicy::WWW,state,edge,insertion);
    extract_maximum_excess(graph,state);
    return result;
}

}  // namespace iadsh
