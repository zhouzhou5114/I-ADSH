#pragma once
#include "hgv.hpp"
#include "flow.hpp"
#include <cmath>
#include <limits>
#include <stdexcept>

namespace iadsh::hgv_detail {
struct FlowStep {
    std::vector<int> set;
    double density = -std::numeric_limits<double>::infinity();
    std::size_t arcs = 0;
};

FlowStep www24_flow_step(
    const Hypergraph&, const Www24Index&, const std::vector<int>& vertices,
    const std::vector<int>& edges, double beta);

// Real-valued improvement and integer-boundary stopping share each network plan.
template <typename Step>
Www24Result density_improvement(
    const Hypergraph& graph,
    const Www24Index& index,
    const std::vector<int>& initial_set,
    double upper_bound,
    double tolerance,
    Step&& step) {
    if (!(tolerance > 0.0)) throw std::runtime_error("WWW24 tolerance must be positive");
    if (initial_set.empty()) throw std::runtime_error("WWW24 initial set must be nonempty");
    if (std::isnan(upper_bound)) throw std::runtime_error("WWW24 upper bound is NaN");
    Www24Result result;
    result.best_set = initial_set;
    result.density = result.best_set == index.reference
        ? static_cast<double>(index.reference_internal_edges) /
            static_cast<double>(index.reference.size())
        : www24_density(graph, index, result.best_set);
    result.initial_density = result.density;
    result.upper_bound = upper_bound;
    if (result.density > upper_bound + tolerance) {
        throw std::runtime_error("WWW24 initial density exceeds the supplied upper bound");
    }
    if (result.density >= upper_bound - tolerance) {
        result.certified_by_upper_bound = true;
        return result;
    }

    while (true) {
        ++result.iterations;
        const auto candidate = step(result.density, &result);
        const double candidate_density = candidate.density;
        if (!candidate.set.empty() && candidate_density > result.density + tolerance) {
            result.best_set = candidate.set;
            result.density = candidate_density;
        } else {
            break;
        }
        if (result.density >= upper_bound - tolerance) {
            result.certified_by_upper_bound = true;
            break;
        }
        if (result.iterations > graph.n + 2) {
            throw std::runtime_error("WWW24 density improvement failed to converge");
        }
    }
    return result;
}

template <typename Step>
Www24Result integer_ceiling_improvement(
    const Hypergraph& graph,
    const Www24Index& index,
    const std::vector<int>& initial_set,
    double tolerance,
    Step&& step) {
    if (!(tolerance > 0.0)) {
        throw std::runtime_error(
            "WWW24 integer-stop tolerance must be positive");
    }
    if (initial_set.empty()) {
        throw std::runtime_error(
            "WWW24 integer-stop initial set must be nonempty");
    }
    Www24Result result;
    result.best_set = initial_set;
    result.density = result.best_set == index.reference
        ? static_cast<double>(index.reference_internal_edges) /
            static_cast<double>(index.reference.size())
        : www24_density(graph, index, result.best_set);
    result.initial_density = result.density;
    int level = static_cast<int>(
        std::ceil(2.0 * result.density - tolerance));

    while (true) {
        const double boundary = 0.5 * static_cast<double>(level);
        ++result.iterations;
        const auto candidate = step(boundary, &result);
        const double candidate_density = candidate.density;
        if (!candidate.set.empty() &&
            candidate_density > boundary + tolerance) {
            const int next_level = static_cast<int>(
                std::ceil(2.0 * candidate_density - tolerance));
            if (next_level <= level) {
                throw std::runtime_error(
                    "WWW24 integer-stop failed to increase the ceiling level");
            }
            level = next_level;
            result.best_set = candidate.set;
            result.density = candidate_density;
        } else {
            result.upper_bound = boundary;
            result.certified_by_upper_bound = true;
            break;
        }
        if (result.iterations >
            static_cast<int>(index.graph_index->active_edges.size()) + graph.n + 2) {
            throw std::runtime_error(
                "WWW24 integer-stop failed to converge");
        }
    }
    return result;
}

}  // namespace iadsh::hgv_detail
