#pragma once
#include "state.hpp"

namespace iadsh {
// Maximum-excess closure at the optimum integer level.
SearchResult batched_ceil_balance_global_all_closures(const Hypergraph&);
SearchResult lazy_batched_ceil_balance_local_all_closures(
    const Hypergraph&, const CeilBalanceQueryState&,
    std::size_t work_cap = std::numeric_limits<std::size_t>::max());
// Certificate-preserving Global plan used to initialize Dynamic-Path.
CertifiedSearchResult batched_ceil_balance_global(
    const Hypergraph&, bool retain_upper_certificate = false);
}  // namespace iadsh
