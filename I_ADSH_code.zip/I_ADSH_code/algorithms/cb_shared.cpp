#include "cb_shared.hpp"
#include "profile.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <functional>
#include <limits>
#include <memory>
#include <queue>
#include <sstream>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>


namespace iadsh {

namespace {
bool owner_allowed(const Hypergraph& graph, std::size_t edge_id, int owner) {
    if (owner == AnchorBank) return true;
    if (owner < 0 || owner >= graph.n || graph.is_anchor[owner]) return false;
    const auto& pins = graph.edges[edge_id].pins;
    return std::binary_search(pins.begin(), pins.end(), owner);
}

Capacity bank_capacity(const Hypergraph& graph, const std::vector<Capacity>& penalty, int theta) {
    Capacity capacity = 0;
    for (int v = 0; v < graph.n; ++v) {
        if (graph.is_anchor[v]) capacity += penalty[static_cast<std::size_t>(v)] + theta;
    }
    return capacity;
}
}  // namespace

CeilBalanceStaticIndex::CeilBalanceStaticIndex(
    const Hypergraph& graph,
    const QueryGraphIndex& supplied_graph_index)
    : graph_index(&supplied_graph_index),
      base_token_owner(supplied_graph_index.base_token_owner),
      base_bank_ordinal(supplied_graph_index.base_bank_ordinal),
      base_vertex_load(supplied_graph_index.base_vertex_load),
      base_held_head(supplied_graph_index.base_held_head),
      base_held_edge(supplied_graph_index.base_held_edge),
      base_held_next(supplied_graph_index.base_held_next),
      base_bank_tokens(supplied_graph_index.base_bank_tokens) {
    graph.validate();
    if (supplied_graph_index.incident_edges.size() !=
            static_cast<std::size_t>(graph.n) ||
        !supplied_graph_index.ceil_balance_ready ||
        base_token_owner.size() != graph.edges.size() ||
        base_held_head.size() != static_cast<std::size_t>(graph.n) ||
        base_held_edge.size() != base_held_next.size()) {
        throw std::runtime_error(
            "CeilBalanceStaticIndex requires a fused Ceil-Balance graph index");
    }
}

CeilBalanceQueryState::CeilBalanceQueryState(
    const Hypergraph& graph,
    const CeilBalanceStaticIndex& supplied_static_index,
    std::vector<int> supplied_reference,
    std::vector<int> supplied_anchors)
    : static_index(&supplied_static_index),
      reference(std::move(supplied_reference)),
      anchors(std::move(supplied_anchors)) {
    if (supplied_static_index.graph_index == nullptr ||
        supplied_static_index.graph_index->incident_edges.size() !=
            static_cast<std::size_t>(graph.n)) {
        throw std::runtime_error(
            "CeilBalanceQueryState does not match the hypergraph");
    }
    std::sort(reference.begin(), reference.end());
    reference.erase(
        std::unique(reference.begin(), reference.end()), reference.end());
    std::sort(anchors.begin(), anchors.end());
    anchors.erase(std::unique(anchors.begin(), anchors.end()), anchors.end());
    if (reference.empty() || anchors.empty()) {
        throw std::runtime_error(
            "Lazy-Batched Ceil-Balance requires nonempty R and A");
    }
    for (int v : reference) {
        measure::vertex(v);
        ++prepare_work;
        if (v < 0 || v >= graph.n ||
            !graph.is_reference[static_cast<std::size_t>(v)]) {
            throw std::runtime_error(
                "reference vector and hypergraph marks disagree");
        }
    }
    for (int v : anchors) {
        measure::vertex(v);
        ++prepare_work;
        if (!std::binary_search(reference.begin(), reference.end(), v) ||
            !graph.is_anchor[static_cast<std::size_t>(v)]) {
            throw std::runtime_error(
                "anchor vector and hypergraph marks disagree");
        }
    }

    const auto& graph_index = *supplied_static_index.graph_index;
    std::vector<int> candidate_internal_edges;
    for (int v : reference) {
        measure::vertex(v);
        const auto& incident =
            graph_index.incident_edges[static_cast<std::size_t>(v)];
#ifdef PROFILE_ACCESS
        for (int e : incident) measure::pin(e, v);
#endif
        for(int e : incident)if(graph.edges[e].active)candidate_internal_edges.push_back(e);
        prepare_work += incident.size();
    }
    std::sort(candidate_internal_edges.begin(), candidate_internal_edges.end());
    candidate_internal_edges.erase(
        std::unique(
            candidate_internal_edges.begin(), candidate_internal_edges.end()),
        candidate_internal_edges.end());
    for (int edge_id : candidate_internal_edges) {
        measure::edge(edge_id);
        bool inside = true;
        for (int v :
             graph.edges[static_cast<std::size_t>(edge_id)].pins) {
            measure::pin(edge_id, v);
            ++prepare_work;
            if (!graph.is_reference[static_cast<std::size_t>(v)]) {
                inside = false;
                break;
            }
        }
        if (inside) ++reference_internal_edges;
    }

    std::vector<int> affected_edges;
    for (int v : reference) {
        measure::vertex(v);
        for (int link = supplied_static_index.base_held_head[
                 static_cast<std::size_t>(v)];
             link >= 0;
             link = supplied_static_index.base_held_next[
                 static_cast<std::size_t>(link)]) {
            measure::pin(supplied_static_index.base_held_edge[static_cast<std::size_t>(link)], v);
            const int candidate=supplied_static_index.base_held_edge[static_cast<std::size_t>(link)];
            if(graph.edges[candidate].active)affected_edges.push_back(candidate);
            ++prepare_work;
        }
    }
    std::sort(affected_edges.begin(), affected_edges.end());
    affected_edges.erase(
        std::unique(affected_edges.begin(), affected_edges.end()),
        affected_edges.end());
    owner_override.reserve(affected_edges.size() * 2 + 1);
    vertex_load_delta.reserve(reference.size() * 2 + 1);
    extra_held_edges.reserve(reference.size() * 2 + 1);

    const int bank_base = graph.n;
    const int bank_count = static_cast<int>(anchors.size());
    const std::size_t base_bank_count =
        supplied_static_index.base_bank_tokens.size();
    for (int edge_id : affected_edges) {
        measure::edge(edge_id);
        const auto& pins =
            graph.edges[static_cast<std::size_t>(edge_id)].pins;
        std::array<int, 2> next_owner{-1, -1};
        int assigned = 0;
        for (int v : pins) {
            measure::pin(edge_id, v);
            ++prepare_work;
            if (graph.is_reference[static_cast<std::size_t>(v)]) continue;
            next_owner[static_cast<std::size_t>(assigned++)] = v;
            if (assigned == 2) break;
        }
        const auto& base_owner =
            supplied_static_index.base_token_owner[
                static_cast<std::size_t>(edge_id)];
        const auto& base_ordinal =
            supplied_static_index.base_bank_ordinal[
                static_cast<std::size_t>(edge_id)];
        for (int token = assigned; token < 2; ++token) {
            const std::size_t position = static_cast<std::size_t>(token);
            if (base_owner[position] == -1) {
                next_owner[position] = bank_base +
                    base_ordinal[position] % bank_count;
            } else {
                const std::size_t appended = extra_bank_edges.size();
                next_owner[position] = bank_base + static_cast<int>(
                    (base_bank_count + appended) %
                    static_cast<std::size_t>(bank_count));
                extra_bank_edges.push_back(edge_id);
            }
        }

        std::array<int, 2> base_actual{-1, -1};
        for (int token = 0; token < 2; ++token) {
            const std::size_t position = static_cast<std::size_t>(token);
            base_actual[position] = base_owner[position] >= 0
                ? base_owner[position]
                : bank_base + base_ordinal[position] % bank_count;
            if (base_actual[position] < graph.n) {
                measure::pin(edge_id, base_actual[position]);
                --vertex_load_delta[base_actual[position]];
            }
            if (next_owner[position] < graph.n) {
                measure::pin(edge_id, next_owner[position]);
                ++vertex_load_delta[next_owner[position]];
                if (next_owner[position] != base_actual[position]) {
                    extra_held_edges[next_owner[position]].push_back(edge_id);
                }
            }
        }
        owner_override.emplace(edge_id, next_owner);
    }
}

bool validate_orientation(
    const Hypergraph& graph,
    RewardPolicy policy,
    const Orientation& orientation,
    std::string* error) {
    if (orientation.x.size() != graph.edges.size()) {
        if (error) *error = "orientation has wrong edge count";
        return false;
    }
    for (std::size_t edge_id = 0; edge_id < graph.edges.size(); ++edge_id) {
        Capacity total = 0;
        for (const auto& item : orientation.x[edge_id]) {
            if (item.second < 0) {
                if (error) *error = "orientation contains a negative token count";
                return false;
            }
            if (item.second > 0 && !owner_allowed(graph, edge_id, item.first)) {
                if (error) *error = "orientation assigns tokens to a disallowed owner";
                return false;
            }
            total += item.second;
        }
        if (total != graph.edge_reward(edge_id, policy)) {
            if (error) {
                std::ostringstream out;
                out << "edge " << edge_id << " owns " << total << " tokens but needs "
                    << graph.edge_reward(edge_id, policy);
                *error = out.str();
            }
            return false;
        }
    }
    return true;
}

bool orientation_feasible(
    const Hypergraph& graph,
    RewardPolicy policy,
    int alpha,
    const Orientation& orientation,
    std::string* error) {
    if (!validate_orientation(graph, policy, orientation, error)) return false;
    if (alpha < 1) {
        if (error) *error = "alpha must be at least one";
        return false;
    }
    const int theta = alpha - 1;
    const auto penalty = graph.penalties();
    std::unordered_map<int, Capacity> load;
    for (const auto& edge_map : orientation.x) {
        for (const auto& item : edge_map) load[item.first] += item.second;
    }
    if (load[AnchorBank] > bank_capacity(graph, penalty, theta)) {
        if (error) *error = "anchor bank is overloaded";
        return false;
    }
    for (int v = 0; v < graph.n; ++v) {
        if (graph.is_anchor[v]) continue;
        if (load[v] > penalty[static_cast<std::size_t>(v)] + theta) {
            if (error) *error = "a vertex owner is overloaded";
            return false;
        }
    }
    return true;
}

}  // namespace iadsh
